import csv
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import time
import requests  # für API-Aufrufe
import traceback  # für detaillierte Fehlermeldungen
import fcntl  # Dateisperre (nur auf Unix/Linux-Systemen)

# Dateipfade
file_path = '/var/www/html/drag/devices.csv'
offline_file = '/var/www/html/drag/offline.csv'
health_file = '/var/www/html/drag/health.txt'
alarm_config_file = '/var/www/html/drag/alarms.csv'
alarm_output_file = '/var/www/html/drag/alarm.csv'

def ping_ip(ip):
    try:
        result = subprocess.run(['ping', '-c', '2', '-W', '2', ip],
                                  capture_output=True, text=True, timeout=6)
        output = result.stdout
        # Zeile mit "packets transmitted" herausfiltern
        stats_line = next((line for line in output.splitlines() if 'packets transmitted' in line), "")
        received = int(stats_line.split(',')[1].strip().split()[0]) if stats_line else 0
        success = received >= 1
        return ip, success
    except Exception as e:
        print(f"⚠️ Error pinging {ip}: {e}")
        traceback.print_exc()
        return ip, False

print("Starte Monitoring-Skript. Fehler werden geloggt – das Skript bricht niemals ab.")

while True:
    try:
        time.sleep(2)

        # ============================
        # Step 1: IP-Adressen aus devices.csv sammeln
        ips = set()
        if not os.path.exists(file_path):
            print(f"❌ CSV file not found: {file_path}")
        else:
            try:
                with open(file_path, newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    if 'ip' not in reader.fieldnames:
                        print("❌ Spalte 'ip' fehlt in der CSV-Datei.")
                    else:
                        for row in reader:
                            ip = row['ip'].strip()
                            if ip:
                                ips.add(ip)
            except Exception as e:
                print(f"⚠️ Fehler beim Lesen der CSV-Datei: {e}")
                traceback.print_exc()

        # Falls keine IPs gefunden wurden, trotzdem health.txt aktualisieren
        if not ips:
            print("ℹ️ Keine IP-Adressen gefunden. Aktualisiere health.txt und warte 5 Sekunden.")
            current_time = int(time.time())
            write_timestamp = False
            try:
                if not os.path.exists(health_file) or os.stat(health_file).st_size == 0:
                    write_timestamp = True
                else:
                    with open(health_file, 'r', encoding='utf-8') as f:
                        content = f.read().strip()
                        if content.isdigit():
                            last_time = int(content)
                            if current_time - last_time > 600:
                                write_timestamp = True
                        else:
                            write_timestamp = True
            except Exception as e:
                print(f"⚠️ Fehler beim Lesen von health.txt: {e}")
                traceback.print_exc()
                write_timestamp = True

            if write_timestamp:
                try:
                    with open(health_file, 'w', encoding='utf-8') as f:
                        fcntl.flock(f, fcntl.LOCK_EX)
                        f.write(str(current_time))
                        f.flush()
                    print(f"📝 Neuer Zeitstempel in health.txt geschrieben: {current_time}")
                except Exception as e:
                    print(f"❌ Fehler beim Schreiben in health.txt: {e}")
                    traceback.print_exc()
            else:
                print("✅ Zeitstempel ist noch gültig – keine Aktualisierung erforderlich.")

            time.sleep(5)
            continue

        # ============================
        # Step 2: Paralleles Pingen der IPs
        print(f"🔄 Starte paralleles Pingen von {len(ips)} IPs...")
        results = {}
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(ping_ip, ip): ip for ip in ips}
            for future in as_completed(futures):
                try:
                    ip, is_online = future.result()
                    results[ip] = "1" if is_online else "0"
                    print(f"{ip} → {'✅ ONLINE' if is_online else '❌ OFFLINE'}")
                except Exception as e:
                    print(f"⚠️ Fehler bei der Auswertung eines Ping-Ergebnisses: {e}")
                    traceback.print_exc()

        # ============================
        # Step 3: devices.csv einlesen, Status aktualisieren und Alarm-Auslösung ermitteln
        updated_rows = []
        header = []
        # alarm_added wird als Dictionary gefüllt: {ip: (category, description, page)}
        alarm_added = {}

        if os.path.exists(file_path):
            try:
                with open(file_path, newline='', encoding='utf-8') as csvfile:
                    reader = csv.reader(csvfile)
                    header = next(reader)
                    # Erforderliche Spalten: ip, online, reserve_1, reserve_2, reserve_3, page, description
                    required_columns = ['ip', 'online', 'reserve_1', 'reserve_2', 'reserve_3', 'page', 'description']
                    missing = [col for col in required_columns if col not in header]
                    if missing:
                        print(f"❌ Fehlende Spalten in der CSV-Datei: {', '.join(missing)}")
                    else:
                        ip_idx = header.index('ip')
                        online_idx = header.index('online')
                        reserve1_idx = header.index('reserve_1')  # Kategorie
                        reserve2_idx = header.index('reserve_2')
                        page_idx = header.index('page')
                        desc_idx = header.index('description')
                        for row in reader:
                            if len(row) < max(ip_idx, online_idx, reserve1_idx, reserve2_idx, page_idx, desc_idx) + 1:
                                updated_rows.append(row)
                                continue
                            ip = row[ip_idx].strip()
                            new_status = results.get(ip)
                            if new_status is not None:
                                # Aktualisiere Online-Status (nur zur Information)
                                if row[online_idx] != new_status:
                                    print(f"📝 Status geändert für {ip} (online): {row[online_idx]} → {new_status}")
                                    row[online_idx] = new_status
                                # Wenn neuer Status "0" (offline) ist, wird der Alarm ausgelöst
                                if new_status == "0":
                                    print(f"🚨 Alarm ausgelöst für {ip}")
                                    # Speichere Kategorie, description und page
                                    alarm_added[ip] = (row[reserve1_idx], row[desc_idx], row[page_idx])
                                    row[reserve2_idx] = "1"
                                else:
                                    row[reserve2_idx] = "0"
                            updated_rows.append(row)
            except Exception as e:
                print(f"⚠️ Fehler beim Verarbeiten der devices.csv: {e}")
                traceback.print_exc()

        # ============================
        # Step 4: devices.csv aktualisieren (Schreiben mit Dateisperre)
        if header and updated_rows:
            try:
                with open(file_path, 'w', newline='', encoding='utf-8') as csvfile:
                    fcntl.flock(csvfile, fcntl.LOCK_EX)
                    writer = csv.writer(csvfile)
                    writer.writerow(header)
                    writer.writerows(updated_rows)
                    csvfile.flush()  # Sicherstellen, dass alle Daten geschrieben wurden.
                print("✅ devices.csv erfolgreich aktualisiert und gesperrt.")
            except Exception as e:
                print(f"❌ Fehler beim Schreiben in devices.csv: {e}")
                traceback.print_exc()
        else:
            print("⚠️ Keine Änderungen in devices.csv gespeichert – Header oder Daten fehlen.")

        # ============================
        # Step 5: Alarm-Konfiguration aus alarms.csv laden
        alarm_config = []
        if os.path.exists(alarm_config_file):
            try:
                with open(alarm_config_file, newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    for row in reader:
                        alarm_config.append(row)
            except Exception as e:
                print(f"⚠️ Fehler beim Lesen von alarms.csv: {e}")
                traceback.print_exc()
        else:
            print(f"⚠️ Alarm-Konfigurationsdatei nicht gefunden: {alarm_config_file}")

        # ============================
        # Step 6: offline.csv aktualisieren – Einträge für neu ausgelöste Alarme hinzufügen
        offline_header = ['ip', 'page', 'description', 'timestamp']
        offline_rows = []
        if os.path.exists(offline_file):
            try:
                with open(offline_file, newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    for row in reader:
                        if 'timestamp' not in row:
                            row['timestamp'] = ""
                        offline_rows.append(row)
            except Exception as e:
                print(f"⚠️ Fehler beim Lesen von offline.csv: {e}")
                traceback.print_exc()

        unique_offline = {row['ip']: row for row in offline_rows}
        current_timestamp = int(time.time())
        for ip, (category, description, page) in alarm_added.items():
            # Suche in alarms.csv nach einem passenden Eintrag, der zur Kategorie passt
            # UND in der Spalte alarm_auto den Wert "1" hat.
            matching_config = None
            for config in alarm_config:
                if config.get('category') == category and config.get('alarm_auto', '').strip() == "1":
                    matching_config = config
                    break
            if not matching_config:
                print(f"ℹ️ Kein Konfigurationseintrag für Kategorie '{category}' mit alarm_auto=1 gefunden – Offline-Eintrag für {ip} wird nicht gesetzt.")
                continue
            # Falls die IP noch nicht in offline.csv vorhanden ist, füge sie hinzu
            if ip not in unique_offline:
                api_value = matching_config.get('api', '').strip()
                if api_value:
                    try:
                        response = requests.get(api_value)
                        print(f"🔔 API für {ip} ausgeführt. Response Code: {response.status_code}")
                    except Exception as e:
                        print(f"⚠️ API-Aufruf für {ip} fehlgeschlagen: {e}")
                        traceback.print_exc()
                offline_rows.append({
                    'ip': ip,
                    'page': page,
                    'description': description,
                    'timestamp': str(current_timestamp)
                })
                unique_offline[ip] = True
                print(f"📝 Offline-Eintrag für {ip} in offline.csv hinzugefügt.")

        try:
            with open(offline_file, 'w', newline='', encoding='utf-8') as csvfile:
                fcntl.flock(csvfile, fcntl.LOCK_EX)
                writer = csv.DictWriter(csvfile, fieldnames=offline_header)
                writer.writeheader()
                writer.writerows(offline_rows)
                csvfile.flush()
            print("✅ offline.csv erfolgreich aktualisiert und gesperrt.")
        except Exception as e:
            print(f"❌ Fehler beim Schreiben in offline.csv: {e}")
            traceback.print_exc()

        # ============================
        # Step 7: alarm.csv aktualisieren – Einträge hinzufügen
        alarm_output_header = ['ip', 'category', 'description', 'timestamp', 'api']
        alarm_output_rows = []
        if os.path.exists(alarm_output_file):
            try:
                with open(alarm_output_file, newline='', encoding='utf-8') as csvfile:
                    reader = csv.DictReader(csvfile)
                    for row in reader:
                        alarm_output_rows.append(row)
            except Exception as e:
                print(f"⚠️ Fehler beim Lesen von alarm.csv: {e}")
                traceback.print_exc()

        unique_alarm_output = {row['ip']: row for row in alarm_output_rows}
        current_timestamp = int(time.time())
        for ip, (category, description, page) in alarm_added.items():
            if ip not in unique_alarm_output:
                matching_config = None
                for config in alarm_config:
                    if config.get('category') == category and config.get('alarm_auto', '').strip() == "1":
                        matching_config = config
                        break
                if matching_config:
                    api_value = matching_config.get('api', '').strip()
                    if api_value:
                        try:
                            response = requests.get(api_value)
                            print(f"🔔 API für {ip} ausgeführt: Response Code: {response.status_code}")
                        except Exception as e:
                            print(f"⚠️ API-Aufruf für {ip} fehlgeschlagen: {e}")
                            traceback.print_exc()
                    alarm_output_rows.append({
                        'ip': ip,
                        'category': category,
                        'description': description,
                        'timestamp': str(current_timestamp),
                        'api': api_value
                    })
                    print(f"📝 Alarm-Eintrag für {ip} zu alarm.csv hinzugefügt (Kategorie: {category}, API: {api_value}).")

        try:
            with open(alarm_output_file, 'w', newline='', encoding='utf-8') as csvfile:
                fcntl.flock(csvfile, fcntl.LOCK_EX)
                writer = csv.DictWriter(csvfile, fieldnames=alarm_output_header)
                writer.writeheader()
                writer.writerows(alarm_output_rows)
                csvfile.flush()
            print("✅ alarm.csv erfolgreich aktualisiert und gesperrt.")
        except Exception as e:
            print(f"❌ Fehler beim Schreiben in alarm.csv: {e}")
            traceback.print_exc()

        # ============================
        # Step 8: health.txt aktualisieren (Zeitstempel, falls älter als 10 Minuten oder leer)
        current_time = int(time.time())
        write_timestamp = False
        try:
            if not os.path.exists(health_file) or os.stat(health_file).st_size == 0:
                write_timestamp = True
            else:
                with open(health_file, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    if content.isdigit():
                        last_time = int(content)
                        if current_time - last_time > 600:
                            write_timestamp = True
                    else:
                        write_timestamp = True
        except Exception as e:
            print(f"⚠️ Fehler beim Lesen von health.txt: {e}")
            traceback.print_exc()
            write_timestamp = True

        if write_timestamp:
            try:
                with open(health_file, 'w', encoding='utf-8') as f:
                    fcntl.flock(f, fcntl.LOCK_EX)
                    f.write(str(current_time))
                    f.flush()
                print(f"📝 Neuer Zeitstempel in health.txt geschrieben: {current_time}")
            except Exception as e:
                print(f"❌ Fehler beim Schreiben in health.txt: {e}")
                traceback.print_exc()
        else:
            print("✅ Zeitstempel ist noch gültig – keine Aktualisierung erforderlich.")

    except Exception as main_e:
        print(f"⚠️ Unerwarteter Fehler in der Hauptschleife: {main_e}")
        traceback.print_exc()
        time.sleep(5)
