<?php
header("Content-Type: application/json");
$devices = [];
$file = "devices.csv";

// Überprüfen, ob die CSV-Datei existiert
if (!file_exists($file)) {
    echo json_encode($devices);
    exit;
}

if (($handle = fopen($file, "r")) !== false) {
    // Versuche, einen geteilten Lock zu erhalten. Falls die Datei gesperrt ist, kurz warten.
    while (!flock($handle, LOCK_SH)) {
        usleep(100000); // 100 ms warten
    }

    // Lese die Header (erste Zeile) der CSV-Datei
    $headers = fgetcsv($handle);
    if ($headers === false) {
        flock($handle, LOCK_UN);
        fclose($handle);
        echo json_encode($devices);
        exit;
    }
    $headerCount = count($headers);

    // Pflichtfelder, in denen ein Wert stehen muss (label darf auch leer sein)
    $requiredFields = ['id', 'type', 'x', 'y', 'page'];

    // Durch alle Zeilen der CSV-Datei iterieren
    while (($row = fgetcsv($handle)) !== false) {
        // Überspringe Zeilen, die komplett leer sind
        if (empty($row) || empty(array_filter($row, function($field) {
            return trim($field) !== '';
        }))) {
            continue;
        }

        // Falls die Anzahl der Werte nicht mit der Spaltenanzahl übereinstimmt, repariere die Zeile:
        // - Fehlende Werte mit leeren Strings auffüllen
        // - Überschüssige Werte abschneiden
        $rowCount = count($row);
        if ($rowCount < $headerCount) {
            $row = array_pad($row, $headerCount, '');
        } elseif ($rowCount > $headerCount) {
            $row = array_slice($row, 0, $headerCount);
        }

        // Assoziatives Array anhand der Header erstellen
        $device = array_combine($headers, $row);
        if ($device === false) {
            continue;
        }

        // Überprüfen, dass in allen Pflichtspalten ein Wert vorhanden ist
        $isValid = true;
        foreach ($requiredFields as $field) {
            if (!isset($device[$field]) || trim($device[$field]) === '') {
                $isValid = false;
                break;
            }
        }
        if (!$isValid) {
            // Überspringe diese Zeile, da ein Pflichtwert fehlt
            continue;
        }

        // Legt die Kategorie fest: Falls in "reserve_1" ein nicht-leerer Wert steht, diesen verwenden, ansonsten "default"
        if (isset($device["reserve_1"]) && trim($device["reserve_1"]) !== "") {
            $device["category"] = trim($device["reserve_1"]);
        } else {
            $device["category"] = "default";
        }

        $devices[] = $device;
    }

    // Sperre wieder freigeben und die Datei schließen
    flock($handle, LOCK_UN);
    fclose($handle);
}

echo json_encode($devices);
?>
