<?php
header("Content-Type: application/json");
$devices = [];

if (!file_exists("devices.csv")) {
    echo json_encode($devices);
    exit;
}

if (($handle = fopen("devices.csv", "r")) !== false) {
    $headers = fgetcsv($handle); // Erste Zeile = Spaltennamen
    while (($row = fgetcsv($handle)) !== false) {
        $device = array_combine($headers, $row);
        // Wenn in reserve_1 ein nicht-leerer Wert steht, als "category" übernehmen, sonst "default"
        if (isset($device["reserve_1"]) && trim($device["reserve_1"]) !== "") {
            $device["category"] = trim($device["reserve_1"]);
        } else {
            $device["category"] = "default";
        }
        $devices[] = $device;
    }
    fclose($handle);
}

echo json_encode($devices);
?>
