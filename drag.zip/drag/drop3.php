<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>Netzwerkplan mit Verbindungen</title>
  <style>
    body { margin: 0; font-family: sans-serif; }
    #toolbar { background: #f0f0f0; padding: 10px; }
    .icon { width: 40px; margin-right: 10px; cursor: grab; }
    #controls { background: #eee; padding: 10px; }
    #page-controls { background: #f9f9f9; padding: 10px; }
    #canvas { height: 600px; background: #ffffff; border: none; position: relative; }
    .device { position: absolute; text-align: center; cursor: move; padding: 5px; border: 2px solid #ccc; border-radius: 5px; background: rgba(255,255,255,0.8); transition: border-color 0.3s ease; }
    .device img { width: 40px; }
    .device.selected { outline: 2px solid blue; }
    .device-label { position: absolute; top: -22px; left: 0; width: 100%; text-align: center; font-size: 16px; font-weight: bold; color: #000; pointer-events: none; }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/leader-line@1.0.7/leader-line.min.js"></script>
</head>
<body>

<div id="toolbar">
  <img src="router.png" class="icon" draggable="true" data-type="Router">
  <img src="switch.png" class="icon" draggable="true" data-type="Switch">
</div>

<div id="page-controls">
  <label>Seite:
    <input type="text" id="page-search" placeholder="🔍 Suchen..." style="margin-right: 10px; padding: 5px;">
    <select id="page-selector"></select>
  </label>
  <button id="add-page">➕ Neue Seite</button>
  <button id="delete-page">🗑️ Seite löschen</button>
</div>

<div id="controls">
  <button id="connect-devices">Geräte verbinden</button>
</div>

<div id="canvas"></div>
<!-- Die Buttons verwenden nun inline onclick, also müssen die Funktionen global verfügbar sein -->
<div id="context-menu" style="display:none; position:absolute; background:#fff; border:1px solid #ccc; padding:10px; z-index:1000;">
  <label>IP/DNS:<br><input type="text" id="context-ip"></label><br><br>
  <label>Beschreibung:<br><input type="text" id="context-desc"></label><br><br>
  <button onclick="saveContextData()">💾 Speichern</button>
  <button onclick="deleteDevice()">🗑️ Löschen</button>
  <button onclick="closeContextMenu()">❌ Abbrechen</button>
</div>

<script>
// Flag, das angibt, ob der aktuelle Drag-Vorgang von einem Toolbar-Icon stammt
let isToolbarDrag = false;

function getUrlParameter(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

const canvas = document.getElementById("canvas");
let selectedDevices = [];
let connections = [];
let currentPage = getUrlParameter("page") || "default";
let availablePages = [];

function getCurrentPage() {
  return currentPage;
}

function updatePageSelector(filter = "") {
  const select = document.getElementById("page-selector");
  select.innerHTML = "";
  const filteredPages = availablePages.filter(p =>
    p.toLowerCase().includes(filter.toLowerCase())
  );
  filteredPages.forEach(p => {
    const option = document.createElement("option");
    option.value = p;
    option.textContent = p;
    if (p === currentPage) option.selected = true;
    select.appendChild(option);
  });
  setupPageSelectorListener();
}

function addNewPage() {
  const name = prompt("Neue Seite benennen:");
  if (!name) return;
  if (!availablePages.includes(name)) {
    fetch("save_page.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ page: name })
    })
    .then(res => res.text())
    .then(() => {
      availablePages.push(name);
      currentPage = name;
      updatePageSelector();
      loadDevicesForPage(currentPage);
    })
    .catch(err => console.error("Fehler beim Hinzufügen der Seite:", err));
  }
}

function changePage(newPage) {
  currentPage = newPage;
  loadDevicesForPage(currentPage);
}

function makeDraggable(el) {
  let offsetX = 0, offsetY = 0, startX = 0, startY = 0, isDragging = false;
  el.addEventListener("mousedown", function (e) {
    // Nur bei Linksklick Drag starten
    if (e.button !== 0) return;
    startX = e.clientX;
    startY = e.clientY;
    offsetX = e.clientX - el.getBoundingClientRect().left;
    offsetY = e.clientY - el.getBoundingClientRect().top;
    function onMouseMove(e) {
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.sqrt(dx*dx + dy*dy) > 5) {
        isDragging = true;
        el.style.left = `${e.pageX - offsetX}px`;
        el.style.top = `${e.pageY - offsetY}px`;
        updateLines(el);
      }
    }
    function onMouseUp() {
      if (isDragging) {
        saveDeviceToServer({
          id: el.id,
          type: el.dataset.type,
          label: el.dataset.label || "",
          ip: el.dataset.ip || "",
          description: el.dataset.label || "",
          x: parseInt(el.style.left),
          y: parseInt(el.style.top),
          page: getCurrentPage()
        });
      }
      isDragging = false;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    }
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
  });
  el.ondragstart = () => false;
}

function updateLines(movedDevice) {
  connections.forEach(conn => {
    if (conn.from === movedDevice || conn.to === movedDevice) {
      conn.line.position();
    }
  });
}

function saveDeviceToServer(data) {
  fetch("save_device.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  })
  .then(res => res.text())
  .then(res => console.log("Gespeichert:", res))
  .catch(err => console.error("Fehler beim Speichern:", err));
}

function loadDevicesForPage(page) {
  // Alte Geräte entfernen
  canvas.querySelectorAll('.device').forEach(d => d.remove());
  // Verbindungen entfernen
  connections.forEach(conn => {
    if (conn.line && typeof conn.line.remove === "function") {
      conn.line.remove();
    }
  });
  connections = [];
  selectedDevices = [];
  // Geräte laden
  fetch("load_devices.php")
    .then(res => res.json())
    .then(devices => {
      const deviceMap = {};
      devices.filter(d => d.page === page).forEach(data => {
        const device = document.createElement("div");
        device.className = "device";
        device.style.left = `${data.x}px`;
        device.style.top = `${data.y}px`;
        device.dataset.type = data.type;
        device.dataset.label = data.description || "";
        device.dataset.ip = data.ip || "";
        device.id = data.id;
        device.title = `IP: ${data.ip || "unbekannt"}\n${data.description || ""}`;
        if (data.description && data.description.trim() !== "") {
          const label = document.createElement("div");
          label.className = "device-label";
          label.textContent = data.description;
          device.appendChild(label);
        }
        const img = document.createElement("img");
        img.src = data.type === "Router" ? "router.png" : "switch.png";
        img.alt = data.type;
        device.appendChild(img);
        canvas.appendChild(device);
        makeDraggable(device);
        deviceMap[data.id] = device;
        device.addEventListener("click", function (e) {
          if (e.button === 2) return;
          if (device.classList.contains("selected")) {
            device.classList.remove("selected");
            selectedDevices = selectedDevices.filter(d => d !== device);
          } else {
            if (selectedDevices.length === 2) {
              const first = selectedDevices.shift();
              first.classList.remove("selected");
            }
            device.classList.add("selected");
            selectedDevices.push(device);
          }
        });
      });
      // Verbindungen laden und zeichnen
      fetch("load_connections.php")
        .then(res => res.json())
        .then(lines => {
          lines.filter(conn => conn.page === page).forEach(conn => {
            const fromEl = deviceMap[conn.from];
            const toEl = deviceMap[conn.to];
            if (fromEl && toEl) {
              const line = new LeaderLine(fromEl, toEl, {
                color: 'gray',
                size: 2,
                path: 'straight',
                startPlug: 'arrow1',
                endPlug: 'arrow1',
                startPlugSize: 1.5,
                endPlugSize: 1.5,
                zIndex: 0
              });
              connections.push({ from: fromEl, to: toEl, line });
            }
          });
        });
    });
}

window.addEventListener("DOMContentLoaded", () => {
  fetch("load_pages.php")
    .then(res => res.json())
    .then(pages => {
      availablePages = pages;
      if (!availablePages.includes("default")) {
        availablePages.unshift("default");
      }
      const pageFromURL = getUrlParameter("page");
      if (pageFromURL && availablePages.includes(pageFromURL)) {
        currentPage = pageFromURL;
      } else if (!availablePages.includes(currentPage)) {
        currentPage = "default";
      }
      updatePageSelector();
      loadDevicesForPage(currentPage);
    });

  document.getElementById("page-selector").addEventListener("change", e => {
    const newPage = e.target.value;
    changePage(newPage);
    const url = new URL(window.location);
    url.searchParams.set("page", newPage);
    window.history.replaceState({}, "", url);
  });
  
  document.getElementById("page-search").addEventListener("input", (e) => {
    const search = e.target.value;
    updatePageSelector(search);
    document.getElementById("page-selector").dispatchEvent(new Event("change"));
  });
  
  document.getElementById("add-page").addEventListener("click", () => {
    addNewPage();
  });

  document.getElementById("connect-devices").addEventListener("click", () => {
    if (selectedDevices.length === 2) {
      const fromId = selectedDevices[0].id;
      const toId = selectedDevices[1].id;
      const line = new LeaderLine(
        selectedDevices[0],
        selectedDevices[1],
        { color: 'gray', size: 2, path: 'straight', startPlug: 'arrow1', endPlug: 'arrow1', startPlugSize: 1.5, endPlugSize: 1.5, zIndex: 0 }
      );
      connections.push({ from: selectedDevices[0], to: selectedDevices[1], line });
      fetch("save_connection.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ from: fromId, to: toId, page: getCurrentPage() })
      }).catch(err => console.error("Fehler beim Speichern der Verbindung:", err));
      selectedDevices.forEach(d => d.classList.remove("selected"));
      selectedDevices = [];
    } else {
      alert("Bitte genau 2 Geräte auswählen.");
    }
  });

  // Toolbar-Icons-Events
  document.querySelectorAll(".icon").forEach(icon => {
    icon.addEventListener("dragstart", e => {
      isToolbarDrag = true;
      e.dataTransfer.setData("type", icon.dataset.type);
      e.dataTransfer.setData("src", icon.src);
    });
    icon.addEventListener("dragend", e => {
      isToolbarDrag = false;
    });
  });

  canvas.addEventListener("dragover", e => e.preventDefault());
  canvas.addEventListener("drop", e => {
    e.preventDefault();
    if (!isToolbarDrag) return;
    const type = e.dataTransfer.getData("type");
    if (!type) return;
    const src = e.dataTransfer.getData("src");
    const device = document.createElement("div");
    device.className = "device";
    device.style.left = `${e.offsetX}px`;
    device.style.top = `${e.offsetY}px`;
    device.dataset.type = type;
    device.id = "device-" + Date.now();
    const img = document.createElement("img");
    img.src = src;
    img.alt = type;
    device.appendChild(img);
    canvas.appendChild(device);
    makeDraggable(device);
    device.addEventListener("click", function () {
      device.classList.toggle("selected");
      if (device.classList.contains("selected")) {
        selectedDevices.push(device);
      } else {
        selectedDevices = selectedDevices.filter(d => d !== device);
      }
    });
    saveDeviceToServer({
      id: device.id,
      type: type,
      label: "",
      ip: "",
      description: "",
      x: parseInt(device.style.left),
      y: parseInt(device.style.top),
      page: getCurrentPage()
    });
  });

  let contextDevice = null;

  canvas.addEventListener("contextmenu", function (e) {
    const device = e.target.closest(".device");
    if (!device) return;
    e.preventDefault();
    contextDevice = device;
    document.getElementById("context-ip").value = device.dataset.ip || "";
    document.getElementById("context-desc").value = device.dataset.label || "";
    const menu = document.getElementById("context-menu");
    menu.style.left = e.pageX + "px";
    menu.style.top = e.pageY + "px";
    menu.style.display = "block";
  });

  function closeContextMenu() {
    document.getElementById("context-menu").style.display = "none";
    contextDevice = null;
  }

  function saveContextData() {
    if (!contextDevice) return;
    const ip = document.getElementById("context-ip").value;
    const desc = document.getElementById("context-desc").value;
    console.log("saveContextData aufgerufen. IP:", ip, "Beschreibung:", desc);
    contextDevice.dataset.ip = ip;
    contextDevice.dataset.label = desc;
    contextDevice.title = `IP: ${ip}\n${desc}`;
    const oldLabel = contextDevice.querySelector(".device-label");
    if (oldLabel) oldLabel.remove();
    if (desc.trim() !== "") {
      const labelDiv = document.createElement("div");
      labelDiv.className = "device-label";
      labelDiv.textContent = desc;
      contextDevice.appendChild(labelDiv);
    }
    saveDeviceToServer({
      id: contextDevice.id,
      type: contextDevice.dataset.type,
      label: desc,
      ip: ip,
      description: desc,
      x: parseInt(contextDevice.style.left),
      y: parseInt(contextDevice.style.top),
      page: getCurrentPage()
    });
    closeContextMenu();
  }

  function deleteDevice() {
    if (!contextDevice) return;
    if (!confirm("Gerät wirklich löschen?")) return;
    connections = connections.filter(conn => {
      if (conn.from === contextDevice || conn.to === contextDevice) {
        conn.line.remove();
        return false;
      }
      return true;
    });
    contextDevice.remove();
    fetch("delete_device.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: contextDevice.id })
    })
    .then(res => res.text())
    .then(res => console.log("Gerät gelöscht:", res));
    closeContextMenu();
  }

  window.addEventListener("click", function (e) {
    const menu = document.getElementById("context-menu");
    if (!menu.contains(e.target)) { menu.style.display = "none"; }
  });
  
  document.getElementById("delete-page").addEventListener("click", () => {
    if (currentPage === "default") {
      alert("Die Standardseite 'default' kann nicht gelöscht werden.");
      return;
    }
    if (!confirm(`Seite '${currentPage}' wirklich löschen?`)) return;
    fetch("delete_page.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ page: currentPage })
    })
    .then(res => res.text())
    .then(() => {
      availablePages = availablePages.filter(p => p !== currentPage);
      currentPage = "default";
      updatePageSelector();
      loadDevicesForPage(currentPage);
    });
  });
  
  function setupPageSelectorListener() {
    const selector = document.getElementById("page-selector");
    selector.onchange = (e) => {
      const newPage = e.target.value;
      changePage(newPage);
      const url = new URL(window.location);
      url.searchParams.set("page", newPage);
      window.history.replaceState({}, "", url);
    };
  }
});

// Hier werden die Funktionen global verfügbar gemacht:
window.saveContextData = saveContextData;
window.deleteDevice = deleteDevice;
window.closeContextMenu = function() {
  document.getElementById("context-menu").style.display = "none";
  contextDevice = null;
};
</script>

</body>
</html>
