<?php
header("Content-Type: application/json");

// Daten einlesen
$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !isset($data["page"])) {
    http_response_code(400);
    echo json_encode(["error" => "Seitenname fehlt"]);
    exit;
}

$pageName = trim($data["page"]);
$file = "pages.json";

// Bestehende Seiten einlesen
$pages = [];
if (file_exists($file)) {
    $json = file_get_contents($file);
    $pages = json_decode($json, true);
    if (!is_array($pages)) {
        $pages = [];
    }
}

// Seite hinzufügen, wenn noch nicht vorhanden
if (!in_array($pageName, $pages)) {
    $pages[] = $pageName;

    // 🔥 Datei neu schreiben
    if (file_put_contents($file, json_encode($pages, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
        echo json_encode(["success" => true, "added" => $pageName]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Konnte pages.json nicht schreiben"]);
    }
} else {
    echo json_encode(["success" => true, "exists" => true]);
}
?>
