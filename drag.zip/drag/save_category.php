<?php
$filename = 'categories.json';
$alarmsCsv = 'alarms.csv';

// Lade vorhandene Kategorien
if (file_exists($filename)) {
    $categories = json_decode(file_get_contents($filename), true);
    if (!is_array($categories)) {
        $categories = ["default"];
    }
} else {
    $categories = ["default"];
}

// Lese Eingabe (als JSON)
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Kategorie pr�fen
$newCategory = isset($data['category']) ? trim($data['category']) : "";
// Umwandeln von Leerzeichen in Unterstriche
$newCategory = str_replace(' ', '_', $newCategory);

if (empty($newCategory)) {
    echo json_encode(["error" => "Keine Kategorie angegeben"]);
    exit;
}

// Nur fortfahren, wenn Kategorie neu ist
if (!in_array($newCategory, $categories)) {
    $categories[] = $newCategory;

    // Versuche, categories.json zu speichern
    if (file_put_contents($filename, json_encode($categories)) !== false) {

        // --- Jetzt: alarms.csv erweitern, wenn Kategorie dort fehlt ---
        if (file_exists($alarmsCsv)) {
            $lines = file($alarmsCsv, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            $header = str_getcsv(array_shift($lines));
            $categoryIndex = array_search("category", $header);
            $alarmAutoIndex = array_search("alarm_auto", $header);

            if ($categoryIndex !== false && $alarmAutoIndex !== false) {
                $categoryExists = false;
                foreach ($lines as $line) {
                    $cols = str_getcsv($line);
                    if (isset($cols[$categoryIndex]) && $cols[$categoryIndex] === $newCategory) {
                        $categoryExists = true;
                        break;
                    }
                }

                if (!$categoryExists) {
                    $newRow = array_fill(0, count($header), "");
                    $newRow[$categoryIndex] = $newCategory;
                    $newRow[$alarmAutoIndex] = "1";
                    $lines[] = $newRow;

                    // Schreibe aktualisierte Datei
                    $file = fopen($alarmsCsv, "w");
                    fputcsv($file, $header);
                    foreach ($lines as $line) {
                        if (!is_array($line)) {
                            $line = str_getcsv($line);
                        }
                        fputcsv($file, $line);
                    }
                    fclose($file);
                }
            }
        }

        echo json_encode([
            "success" => "Kategorie hinzugef�gt",
            "categories" => $categories
        ]);
    } else {
        echo json_encode(["error" => "Fehler beim Schreiben in die Datei"]);
    }
} else {
    echo json_encode(["error" => "Kategorie existiert bereits"]);
}
?>
