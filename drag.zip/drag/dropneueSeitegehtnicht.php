<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>Netzwerkplan mit Verbindungen</title>
  <style>
    body { margin: 0; font-family: sans-serif; }
    #toolbar { background: #f0f0f0; padding: 10px; }
    .icon { width: 40px; margin-right: 10px; cursor: grab; }
    #controls { background: #eee; padding: 10px; }
    #page-controls { background: #f9f9f9; padding: 10px; }
    #canvas { height: 600px; background: #ffffff; border: none; position: relative; }
    .device {
      position: absolute;
      text-align: center;
      cursor: move;
      padding: 5px;
      border: 2px solid #ccc;
      border-radius: 5px;
      background: rgba(255,255,255,0.8);
      transition: border-color 0.3s ease;
    }
    .device img { width: 40px; }
    .device.selected { outline: 2px solid blue; }
    .device-label {
      position: absolute;
      top: -22px;
      left: 0;
      width: 100%;
      text-align: center;
      font-size: 16px;
      font-weight: bold;
      color: #000;
      pointer-events: none;
    }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/leader-line@1.0.7/leader-line.min.js"></script>
</head>
<body>

<div id="toolbar">
  <img src="router.png" class="icon" draggable="true" data-type="Router">
  <img src="switch.png" class="icon" draggable="true" data-type="Switch">
</div>

<div id="page-controls">
  <label>Seite:
    <select id="page-selector"></select>
  </label>
  <button id="add-page">➕ Neue Seite</button>
  <button id="delete-page">🗑️ Seite löschen</button>
</div>

<div id="controls">
  <button id="connect-devices">Geräte verbinden</button>
</div>

<div id="canvas"></div>

<!-- Kontextmenü (Inline-Handler benötigen globale Funktionen) -->
<div id="context-menu" style="display:none; position:absolute; background:#fff; border:1px solid #ccc; padding:10px; z-index:1000;">
  <label>IP/DNS:<br><input type="text" id="context-ip"></label><br><br>
  <label>Beschreibung:<br><input type="text" id="context-desc"></label><br><br>
  <button onclick="saveContextData()">💾 Speichern</button>
  <button onclick="deleteDevice()">🗑️ Löschen</button>
  <button onclick="closeContextMenu()">❌ Abbrechen</button>
</div>

<script>
  // Globale Variablen
  const canvas = document.getElementById("canvas");
  let selectedDevices = [];
  let connections = [];
  let currentPage = "default";
  let availablePages = [];
  let contextDevice = null;

  // Für Toolbar-Icons: Drag-Abstand messen
  let iconWasDragged = false;
  let iconDragStartX = 0;
  let iconDragStartY = 0;
  const DRAG_THRESHOLD = 20; // Pixel

  function getCurrentPage() {
    return currentPage;
  }

  function updatePageSelector() {
    const select = document.getElementById("page-selector");
    select.innerHTML = "";
    availablePages.forEach(p => {
      const option = document.createElement("option");
      option.value = p;
      option.textContent = p;
      if (p === currentPage) option.selected = true;
      select.appendChild(option);
    });
  }

  function addNewPage() {
    const name = prompt("Neue Seite benennen:");
    if (!name) return;
    if (!availablePages.includes(name)) {
      fetch("save_page.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ page: name })
      })
      .then(res => res.text())
      .then(() => {
        availablePages.push(name);
        currentPage = name;
        updatePageSelector();
        loadDevicesForPage(currentPage);
      });
    }
  }

  function changePage(newPage) {
    currentPage = newPage;
    loadDevicesForPage(currentPage);
  }

  // Verschiebbar machen (nur Linksklick)
  function makeDraggable(el) {
    el.addEventListener("mousedown", function (e) {
      if (e.button !== 0) return; // Nur Linksklick
      let offsetX = e.clientX - el.getBoundingClientRect().left;
      let offsetY = e.clientY - el.getBoundingClientRect().top;
      let isDragging = true;
      function onMouseMove(e) {
        if (isDragging) {
          el.style.left = `${e.pageX - offsetX}px`;
          el.style.top = `${e.pageY - offsetY}px`;
          updateLines(el);
        }
      }
      function onMouseUp() {
        isDragging = false;
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        window.removeEventListener("mouseup", onMouseUp);
        saveDeviceToServer({
          id: el.id,
          type: el.dataset.type,
          label: el.dataset.label || "",
          ip: el.dataset.ip || "",
          description: el.dataset.label || "",
          x: parseInt(el.style.left),
          y: parseInt(el.style.top),
          page: getCurrentPage()
        });
      }
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
      window.addEventListener("mouseup", onMouseUp);
    });
    el.ondragstart = () => false;
  }

  function updateLines(movedDevice) {
    connections.forEach(conn => {
      if (conn.from === movedDevice || conn.to === movedDevice) {
        conn.line.position();
      }
    });
  }

  function saveDeviceToServer(data) {
    fetch("save_device.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    })
    .then(res => res.text())
    .then(res => console.log("Gespeichert:", res));
  }

  // Laden der Geräte und Verbindungen der aktuellen Seite
  function loadDevicesForPage(page) {
    // Entferne vorhandene Verbindungslinien
    connections.forEach(conn => {
      if (conn.line && typeof conn.line.remove === "function") {
        conn.line.remove();
      }
    });
    connections = [];
    selectedDevices = [];
    canvas.innerHTML = "";
    fetch("load_devices.php")
      .then(res => res.json())
      .then(devices => {
        devices.filter(d => d.page === page).forEach(data => {
          const device = document.createElement("div");
          device.className = "device";
          device.style.left = `${data.x}px`;
          device.style.top = `${data.y}px`;
          device.dataset.type = data.type;
          device.dataset.label = data.description || "";
          device.dataset.ip = data.ip || "";
          device.id = data.id;
          device.title = `IP: ${data.ip || "unbekannt"}\n${data.description || ""}`;
          if (data.description && data.description.trim() !== "") {
            const label = document.createElement("div");
            label.className = "device-label";
            label.textContent = data.description;
            device.appendChild(label);
          }
          const img = document.createElement("img");
          img.src = data.type === "Router" ? "router.png" : "switch.png";
          img.alt = data.type;
          device.appendChild(img);
          canvas.appendChild(device);
          makeDraggable(device);
          device.addEventListener("click", function () {
            device.classList.toggle("selected");
            if (device.classList.contains("selected")) {
              selectedDevices.push(device);
            } else {
              selectedDevices = selectedDevices.filter(d => d !== device);
            }
          });
        });
      })
      .then(() => {
        // Anschließend Verbindungen laden (nur der aktuellen Seite)
        fetch("load_connections.php")
          .then(res => res.json())
          .then(lines => {
            lines.filter(conn => conn.page === page).forEach(conn => {
              const fromEl = document.getElementById(conn.from);
              const toEl = document.getElementById(conn.to);
              if (fromEl && toEl) {
                const line = new LeaderLine(fromEl, toEl, {
                  color: 'gray',
                  size: 2,
                  path: 'straight',
                  startPlug: 'arrow1',
                  endPlug: 'arrow1',
                  startPlugSize: 1.5,
                  endPlugSize: 1.5,
                  zIndex: 0
                });
                connections.push({ from: fromEl, to: toEl, line });
              }
            });
          });
      });
  }

  // Verbindung erstellen und auf dem Server speichern
  document.getElementById("connect-devices").addEventListener("click", () => {
    console.log("Connect-Button geklickt, ausgewählte Geräte:", selectedDevices.length);
    if (selectedDevices.length === 2) {
      const fromId = selectedDevices[0].id;
      const toId = selectedDevices[1].id;
      const line = new LeaderLine(
        selectedDevices[0],
        selectedDevices[1],
        { color: 'gray', size: 2, path: 'straight' }
      );
      connections.push({ from: selectedDevices[0], to: selectedDevices[1], line });
      fetch("save_connection.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ from: fromId, to: toId, page: getCurrentPage() })
      })
      .then(res => res.text())
      .then(res => console.log("Verbindung gespeichert:", res))
      .catch(err => console.error("Fehler beim Speichern der Verbindung:", err));
      selectedDevices.forEach(d => d.classList.remove("selected"));
      selectedDevices = [];
    } else {
      alert("Bitte genau 2 Geräte auswählen.");
    }
  });

  // Toolbar-Icons: Drag-Events
  document.querySelectorAll(".icon").forEach(icon => {
    icon.addEventListener("dragstart", e => {
      iconDragStartX = e.clientX;
      iconDragStartY = e.clientY;
      iconWasDragged = false;
      e.dataTransfer.setData("type", icon.dataset.type);
      e.dataTransfer.setData("src", icon.src);
      // Markiere, dass der Drag von der Toolbar stammt
      e.dataTransfer.setData("fromToolbar", "true");
    });
    icon.addEventListener("drag", e => {
      const dx = e.clientX - iconDragStartX;
      const dy = e.clientY - iconDragStartY;
      if (Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD) {
        iconWasDragged = true;
      }
    });
    icon.addEventListener("dragend", e => {
      // Wir lassen das Flag hier unverändert, es wird im Drop zurückgesetzt.
    });
  });

  // Drop-Event am Canvas für Toolbar-Icons
  canvas.addEventListener("dragover", e => e.preventDefault());
  canvas.addEventListener("drop", e => {
    e.preventDefault();
    // Nur verarbeiten, wenn der Drop vom Toolbar stammt
    if (e.dataTransfer.getData("fromToolbar") !== "true") return;
    if (e.target !== canvas) return;
    if (!iconWasDragged) return;
    const type = e.dataTransfer.getData("type");
    const src = e.dataTransfer.getData("src");
    if (!type || !src) return;
    // Nach dem Drop Flag zurücksetzen
    iconWasDragged = false;
    // Optional: DataTransfer-Daten löschen
    e.dataTransfer.clearData();
    const device = document.createElement("div");
    device.className = "device";
    device.style.left = `${e.offsetX}px`;
    device.style.top = `${e.offsetY}px`;
    device.dataset.type = type;
    device.id = "device-" + Date.now();
    const img = document.createElement("img");
    img.src = src;
    img.alt = type;
    device.appendChild(img);
    canvas.appendChild(device);
    makeDraggable(device);
    device.addEventListener("click", function () {
      device.classList.toggle("selected");
      if (device.classList.contains("selected")) {
        selectedDevices.push(device);
      } else {
        selectedDevices = selectedDevices.filter(d => d !== device);
      }
    });
    saveDeviceToServer({
      id: device.id,
      type: type,
      label: "",
      ip: "",
      description: "",
      x: parseInt(device.style.left),
      y: parseInt(device.style.top),
      page: getCurrentPage()
    });
  });

  // Kontextmenü (Rechtsklick auf ein Gerät)
  canvas.addEventListener("contextmenu", function (e) {
    const device = e.target.closest(".device");
    if (!device) return;
    e.preventDefault();
    contextDevice = device;
    document.getElementById("context-ip").value = device.dataset.ip || "";
    document.getElementById("context-desc").value = device.dataset.label || "";
    const menu = document.getElementById("context-menu");
    menu.style.left = e.pageX + "px";
    menu.style.top = e.pageY + "px";
    menu.style.display = "block";
  });

  function closeContextMenu() {
    document.getElementById("context-menu").style.display = "none";
    contextDevice = null;
  }

  function saveContextData() {
    if (!contextDevice) return;
    const ip = document.getElementById("context-ip").value;
    const desc = document.getElementById("context-desc").value;
    contextDevice.dataset.ip = ip;
    contextDevice.dataset.label = desc;
    contextDevice.title = `IP: ${ip}\n${desc}`;
    const oldLabel = contextDevice.querySelector(".device-label");
    if (oldLabel) oldLabel.remove();
    if (desc.trim() !== "") {
      const labelDiv = document.createElement("div");
      labelDiv.className = "device-label";
      labelDiv.textContent = desc;
      contextDevice.appendChild(labelDiv);
    }
    saveDeviceToServer({
      id: contextDevice.id,
      type: contextDevice.dataset.type,
      label: desc,
      ip: ip,
      description: desc,
      x: parseInt(contextDevice.style.left),
      y: parseInt(contextDevice.style.top),
      page: getCurrentPage()
    });
    closeContextMenu();
  }

  window.addEventListener("click", function (e) {
    const menu = document.getElementById("context-menu");
    if (!menu.contains(e.target)) {
      menu.style.display = "none";
    }
  });

  document.getElementById("delete-page").addEventListener("click", () => {
    if (currentPage === "default") {
      alert("Die Standardseite 'default' kann nicht gelöscht werden.");
      return;
    }
    if (!confirm(`Seite '${currentPage}' wirklich löschen?`)) return;
    fetch("delete_page.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ page: currentPage })
    })
    .then(res => res.text())
    .then(() => {
      availablePages = availablePages.filter(p => p !== currentPage);
      currentPage = "default";
      updatePageSelector();
      loadDevicesForPage(currentPage);
    });
  });

  function deleteDevice() {
    if (!contextDevice) return;
    if (!confirm("Gerät wirklich löschen?")) return;
    connections = connections.filter(conn => {
      if (conn.from === contextDevice || conn.to === contextDevice) {
        conn.line.remove();
        return false;
      }
      return true;
    });
    contextDevice.remove();
    fetch("delete_device.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: contextDevice.id })
    })
    .then(res => res.text())
    .then(res => console.log("Gerät gelöscht:", res));
    closeContextMenu();
  }

  // Regelmäßig Geräte aktualisieren (z.B. Online-Status)
  setInterval(() => {
    fetch("load_devices.php")
      .then(res => res.json())
      .then(devices => {
        devices.filter(d => d.page === currentPage).forEach(data => {
          const el = document.getElementById(data.id);
          if (el) {
            const isOnline = data.online === "1";
            el.style.borderColor = isOnline ? "green" : "red";
          }
        });
      });
  }, 10000);

  // Initialisierung: Seiten laden, Dropdown aktualisieren und Geräte laden
  window.addEventListener("DOMContentLoaded", () => {
    fetch("load_pages.php")
      .then(res => res.json())
      .then(pages => {
        availablePages = pages && pages.length ? pages : ["default"];
        if (!availablePages.includes("default")) availablePages.unshift("default");
        updatePageSelector();
        loadDevicesForPage(currentPage);
      })
      .catch(err => {
        console.error("Fehler beim Laden der Seiten:", err);
        availablePages = ["default"];
        updatePageSelector();
        loadDevicesForPage(currentPage);
      });

    document.getElementById("page-selector").addEventListener("change", e => {
      changePage(e.target.value);
    });

    // Für Toolbar-Icons
    document.querySelectorAll(".icon").forEach(icon => {
      icon.addEventListener("dragstart", e => {
        iconDragStartX = e.clientX;
        iconDragStartY = e.clientY;
        iconWasDragged = false;
        e.dataTransfer.setData("type", icon.dataset.type);
        e.dataTransfer.setData("src", icon.src);
        // Markiere, dass der Drag vom Toolbar stammt
        e.dataTransfer.setData("fromToolbar", "true");
      });
      icon.addEventListener("drag", e => {
        const dx = e.clientX - iconDragStartX;
        const dy = e.clientY - iconDragStartY;
        if (Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD) {
          iconWasDragged = true;
        }
      });
      icon.addEventListener("dragend", e => {
        // Keine zusätzliche Aktion
      });
    });

    canvas.addEventListener("dragover", e => e.preventDefault());
    canvas.addEventListener("drop", e => {
      e.preventDefault();
      // Prüfen, ob der Drop vom Toolbar-Icon stammt
      if (e.dataTransfer.getData("fromToolbar") !== "true") return;
      if (e.target !== canvas) return;
      if (!iconWasDragged) return;
      const type = e.dataTransfer.getData("type");
      const src = e.dataTransfer.getData("src");
      if (!type || !src) return;
      // Nach dem Drop Flag zurücksetzen und DataTransfer leeren
      e.dataTransfer.clearData();
      iconWasDragged = false;
      const device = document.createElement("div");
      device.className = "device";
      device.style.left = `${e.offsetX}px`;
      device.style.top = `${e.offsetY}px`;
      device.dataset.type = type;
      device.id = "device-" + Date.now();
      const img = document.createElement("img");
      img.src = src;
      img.alt = type;
      device.appendChild(img);
      canvas.appendChild(device);
      makeDraggable(device);
      device.addEventListener("click", function () {
        device.classList.toggle("selected");
        if (device.classList.contains("selected")) {
          selectedDevices.push(device);
        } else {
          selectedDevices = selectedDevices.filter(d => d !== device);
        }
      });
      saveDeviceToServer({
        id: device.id,
        type: type,
        label: "",
        ip: "",
        description: "",
        x: parseInt(device.style.left),
        y: parseInt(device.style.top),
        page: getCurrentPage()
      });
    });
  });
</script>

</body>
</html>
