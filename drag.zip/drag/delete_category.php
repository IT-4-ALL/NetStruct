<?php
$filename = 'categories.json';

// Lade die vorhandenen Kategorien
if (file_exists($filename)) {
    $categories = json_decode(file_get_contents($filename), true);
    if (!is_array($categories)) {
        $categories = ["default"];
    }
} else {
    $categories = ["default"];
}

// Eingabe auslesen (als JSON)
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Die zu l�schende Kategorie
$categoryToDelete = isset($data['category']) ? trim($data['category']) : "";
if (empty($categoryToDelete)) {
    echo json_encode(["error" => "Keine Kategorie angegeben"]);
    exit;
}

// Die Standardkategorie 'default' darf nicht gel�scht werden
if ($categoryToDelete === "default") {
    echo json_encode(["error" => "Die Standardkategorie 'default' kann nicht gel�scht werden"]);
    exit;
}

// Pr�fen, ob die Kategorie existiert
if (!in_array($categoryToDelete, $categories)) {
    echo json_encode(["error" => "Kategorie existiert nicht"]);
    exit;
}

// Kategorie aus der Liste entfernen
$categories = array_filter($categories, function($cat) use ($categoryToDelete) {
    return $cat !== $categoryToDelete;
});
$categories = array_values($categories);

// Speichere die aktualisierte Liste in der JSON-Datei
if (file_put_contents($filename, json_encode($categories)) !== false) {
    echo json_encode(["success" => "Kategorie gel�scht", "categories" => $categories]);
} else {
    echo json_encode(["error" => "Fehler beim Schreiben in die Datei"]);
}

// Setze $category f�r weitere Operationen
$category = $categoryToDelete;

$logfile = 'log.txt';
$csvfile = 'devices.csv';

if (empty($category)) {
    $errorMsg = "Keine Kategorie angegeben";
    file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: $errorMsg\n", FILE_APPEND);
    echo json_encode(["error" => $errorMsg]);
    exit;
}

$message = "Die Kategorie '{$category}' wurde ausgew�hlt";
file_put_contents($logfile, date("Y-m-d H:i:s") . " - Info: $message\n", FILE_APPEND);

// ------------------------------
// Bearbeitung von devices.csv
// ------------------------------
if (file_exists($csvfile)) {
    $rows = [];
    $header = [];

    if (($handle = fopen($csvfile, 'r')) !== false) {
        $header = fgetcsv($handle); // Kopfzeile einlesen
        while (($dataRow = fgetcsv($handle)) !== false) {
            $rows[] = $dataRow;
        }
        fclose($handle);
    }

    // Finde den Spaltenindex f�r 'reserve_1'
    $reserve1Index = array_search('reserve_1', $header);
    if ($reserve1Index !== false) {
        foreach ($rows as &$row) {
            if (isset($row[$reserve1Index]) && $row[$reserve1Index] === $category) {
                $row[$reserve1Index] = 'default';
            }
        }
        unset($row); // Referenz aufheben

        // �berschreibe die CSV-Datei
        if (($handle = fopen($csvfile, 'w')) !== false) {
            fputcsv($handle, $header);
            foreach ($rows as $row) {
                fputcsv($handle, $row);
            }
            fclose($handle);
            file_put_contents($logfile, date("Y-m-d H:i:s") . " - CSV: Kategorie '{$category}' in 'reserve_1' durch 'default' ersetzt\n", FILE_APPEND);
        } else {
            file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: Konnte devices.csv nicht zum Schreiben �ffnen\n", FILE_APPEND);
        }
    } else {
        file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: Spalte 'reserve_1' nicht gefunden\n", FILE_APPEND);
    }
} else {
    file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: CSV-Datei 'devices.csv' nicht gefunden\n", FILE_APPEND);
}

// ------------------------------
// Bearbeitung von alarms.csv
// ------------------------------
$alarmCsvFile = 'alarms.csv';
if (file_exists($alarmCsvFile)) {
    $alarmRows = [];
    $alarmHeader = [];

    if (($handle = fopen($alarmCsvFile, 'r')) !== false) {
        $alarmHeader = fgetcsv($handle); // Kopfzeile einlesen
        while (($dataRow = fgetcsv($handle)) !== false) {
            $alarmRows[] = $dataRow;
        }
        fclose($handle);
    }

    // Finde den Spaltenindex f�r 'category'
    $categoryIndex = array_search('category', $alarmHeader);
    if ($categoryIndex !== false) {
        // Entferne alle Zeilen, in denen die Kategorie �bereinstimmt
        $filteredAlarmRows = array_filter($alarmRows, function($row) use ($categoryIndex, $category) {
            return !(isset($row[$categoryIndex]) && trim($row[$categoryIndex]) === $category);
        });
        $filteredAlarmRows = array_values($filteredAlarmRows);

        // �berschreibe die alarms.csv mit Kopfzeile und den gefilterten Zeilen
        if (($handle = fopen($alarmCsvFile, 'w')) !== false) {
            fputcsv($handle, $alarmHeader);
            foreach ($filteredAlarmRows as $row) {
                fputcsv($handle, $row);
            }
            fclose($handle);
            file_put_contents($logfile, date("Y-m-d H:i:s") . " - Alarms CSV: Zeilen mit Kategorie '{$category}' entfernt\n", FILE_APPEND);
        } else {
            file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: Konnte alarms.csv nicht zum Schreiben �ffnen\n", FILE_APPEND);
        }
    } else {
        file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: Spalte 'category' in alarms.csv nicht gefunden\n", FILE_APPEND);
    }
} else {
    file_put_contents($logfile, date("Y-m-d H:i:s") . " - Fehler: CSV-Datei 'alarms.csv' nicht gefunden\n", FILE_APPEND);
}

echo json_encode(["message" => $message]);
?>
