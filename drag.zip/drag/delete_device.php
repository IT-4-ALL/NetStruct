<?php
$data = json_decode(file_get_contents("php://input"), true);
$deviceId = $data["id"];

$devicesFile = "devices.csv";
$alarmFile = "offline.csv";

// 1. Load devices.csv
$devices = array_map("str_getcsv", file($devicesFile));
$header = array_shift($devices); // erste Zeile = Header

$deviceIP = null;
$newDevices = [];

// 2. Finde und entferne das Gerät mit passender ID
foreach ($devices as $row) {
    if (trim($row[0]) === trim($deviceId)) {
        $deviceIP = trim($row[3]); // Spalte 3 = IP
        continue; // Zeile überspringen (löschen)
    }
    $newDevices[] = $row;
}

// Funktion zum Schreiben in eine CSV-Datei mit File-Locking und Retry-Mechanismus
function writeCsvWithLock($filePath, $headerRow, $rows, $maxWaitTime = 5) {
    $fp = fopen($filePath, "w");
    if (!$fp) {
        die("Fehler beim Öffnen der Datei $filePath.");
    }
    
    $waited = 0;
    // Versuche, einen exklusiven Lock non-blocking zu bekommen
    while (!flock($fp, LOCK_EX | LOCK_NB)) {
        if ($waited >= $maxWaitTime) {
            fclose($fp);
            die("Die Datei $filePath ist gesperrt und konnte nach $maxWaitTime Sekunden nicht entsperrt werden.");
        }
        sleep(1);
        $waited++;
    }
    
    // Schreibe Header und Daten
    fputcsv($fp, $headerRow);
    foreach ($rows as $row) {
        fputcsv($fp, $row);
    }
    fflush($fp);            // Daten in die Datei schreiben
    flock($fp, LOCK_UN);     // Sperre wieder freigeben
    fclose($fp);
}

// 3. Schreibe devices.csv neu
writeCsvWithLock($devicesFile, $header, $newDevices);

// 4. Wenn IP gefunden, bereinige offline.csv (Alarm-Datei)
$deletedAlarms = 0;
if ($deviceIP) {
    $alarms = array_map("str_getcsv", file($alarmFile));
    $alarmHeader = array_shift($alarms);
    
    // Filtere alle Zeilen heraus, die zur gelöschten IP passen
    $filteredAlarms = array_filter($alarms, function($row) use ($deviceIP, &$deletedAlarms) {
        if (trim($row[0]) === trim($deviceIP)) {
            $deletedAlarms++;
            return false;
        }
        return true;
    });
    
    // 5. Schreibe offline.csv neu
    writeCsvWithLock($alarmFile, $alarmHeader, $filteredAlarms);
}

// 6. Rückgabe der Bestätigung
echo "Device deleted. Alarms removed for IP {$deviceIP}: {$deletedAlarms}";
?>
