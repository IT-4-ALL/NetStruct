<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta http-equiv="Expires" content="0" />

  <title>Network Diagram with Connections</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: #f2f4f8;
      color: #333;
    }

    /* Modernize Toolbar */
    #toolbar {
      background: #ffffff;
      padding: 10px;
      border-radius: 10px;
      margin-bottom: 15px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
    .icon {
      width: 40px;
      margin-right: 10px;
      cursor: grab;
    }

    /* Control Button Area */
    #controls {
      display: flex;
      align-items: center;
      gap: 10px; /* Spacing between buttons */
      background: #ffffff;
      padding: 10px;
      border-radius: 10px;
      margin-bottom: 20px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }

    /* Canvas */
    #canvas {
      height: 600px;
      background: #ffffff;
      border: none;
      position: relative;
      border-radius: 10px;
      box-shadow: inset 0 0 5px rgba(0,0,0,0.05);
    }

    /* Device Styling */
    .device {
      position: absolute;
      text-align: center;
      cursor: move;
      padding: 5px;
      border: 2px solid #ccc;
      border-radius: 10px;
      background: rgba(255,255,255,0.95);
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }
    .device:hover {
      box-shadow: 0 4px 8px rgba(0,0,0,0.08);
    }
    .device img {
      width: 40px;
    }
    .device.selected {
      outline: 2px solid #007bff;
    }
    .device-label {
      position: absolute;
      top: -22px;
      left: 0;
      width: 100%;
      text-align: center;
      font-size: 15px;
      font-weight: bold;
      color: #222;
      pointer-events: none;
    }

    /* Modern Tabs */
    .tab-container {
      display: flex;
      background: #ffffff;
      padding: 10px;
      border-bottom: 1px solid #ccc;
      border-radius: 10px;
      margin-bottom: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
    .tab-button {
      padding: 8px 14px;
      margin-right: 5px;
      cursor: pointer;
      background: #e0e0e0;
      border: none;
      border-radius: 8px;
      transition: all 0.2s ease;
    }
    .tab-button:hover {
      background: #007bff;
      color: white;
    }
    .tab-button.active {
      background: #007bff;
      color: white;
      font-weight: bold;
    }

    /* Modern Dropdown */
    .dropdown {
      display: none;
      position: absolute;
      top: 50px;
      left: 10px;
      background: #fff;
      border: 1px solid #ccc;
      padding: 10px;
      z-index: 1000;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    }
    .dropdown.active {
      display: block;
    }
    .dropdown img {
      width: 55px;
      margin: 5px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }
    .dropdown img:hover {
      transform: scale(1.1);
    }

    /* Top Controls */
    #top-controls {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
      background: #ffffff;
      padding: 15px;
      margin-bottom: 20px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }
    #page-controls,
    #category-controls {
      flex: 1;
      min-width: 250px;
    }
    #page-controls label,
    #category-controls label {
      font-weight: 600;
      display: block;
      margin-bottom: 6px;
    }
    #page-controls select,
    #category-controls select {
      width: 100%;
      padding: 8px;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
      font-size: 14px;
      background: #f9f9f9;
    }

    /* Uniform Buttons */
    #page-controls button,
    #category-controls button,
    #controls button {
      background: #007bff;
      border: none;
      color: white;
      padding: 8px 12px;
      margin-right: 8px;
      margin-bottom: 6px;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.2s ease;
      font-size: 14px;
    }
    #page-controls button:hover,
    #category-controls button:hover,
    #controls button:hover {
      background: #0056b3;
    }
    /* Special for Connect Devices Button */
    #connect-devices {
      background: #28a745;
    }
    #connect-devices:hover {
      background: #218838;
    }
    .tab-button:first-child {
      background-color: #d32f2f; /* Signal Red */
      color: white;
      font-weight: bold;
    }
    .tab-button:first-child:hover {
      background-color: #b71c1c;
    }

    /* Settings Button (Notification Settings) */
    #settings-btn {
      background-color: #FFA500 !important; /* Orange */
      border: none;
      color: white;
      font-size: 32px;
      cursor: pointer;
      padding: 12px 20px;
      transition: transform 0.2s ease, background-color 0.2s ease;
      height: 50px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    #settings-btn:hover {
      transform: scale(1.05);
    }
    /* Alerts Button (Current Alerts) */
    #alerts-btn {
      border: none;
      color: white;
      font-size: 32px;
      cursor: pointer;
      padding: 12px 20px;
      transition: transform 0.2s ease, background-color 0.2s ease;
      height: 50px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    #alerts-btn:hover {
      transform: scale(1.05);
    }
   
   .button-container {
  display: inline-block;
  padding: 5px;
}

.control-button {
  font-size: 18px;
  padding: 12px 24px;
  border: none;
  border-radius: 16px; /* More rounded */
  background: linear-gradient(45deg, #28a745, #007bff); /* Green to blue gradient */
  color: #fff;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* 3D effect */
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.control-button:hover {
  transform: translateY(-2px); /* Lift effect */
  box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
}

.control-button:active {
  transform: translateY(0);
  box-shadow: 0 3px 4px rgba(0, 0, 0, 0.2);
}
    
  </style>
  <script src="https://cdn.jsdelivr.net/npm/leader-line@1.0.7/leader-line.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>
  <!-- Tab Headers -->
  <div class="tab-container">
    <button class="tab-button">Close</button>  
    <button class="tab-button" data-tab="router">Router</button>
    <button class="tab-button" data-tab="firewall">Firewall</button>
    <button class="tab-button" data-tab="switch">Switch</button>
    <button class="tab-button" data-tab="access-point">Access Point</button>
    <button class="tab-button" data-tab="server">Server</button>
    <button class="tab-button" data-tab="client">Client</button>
    <button class="tab-button" data-tab="nas">NAS</button>
    <button class="tab-button" data-tab="modem">Modem</button>
    <button class="tab-button" data-tab="proxy">Proxy</button>
    <button class="tab-button" data-tab="repeater">Repeater</button>
    <button class="tab-button" data-tab="gateway">Gateway</button>
    <button class="tab-button" data-tab="voip">VoIP</button>
    <button class="tab-button" data-tab="cam">Multimedia</button>
    <button class="tab-button" data-tab="printer">Printer</button>
    <button class="tab-button" data-tab="reader">Reader</button>
    <button class="tab-button" data-tab="other">Other</button>
    <!-- More tabs can be added here -->
  </div>
<!-- Embed the iframe at the top -->
  <iframe src="https://itfourall.com/banner_network.php" width="100%" height="100" style="border: none;"></iframe>
  <!-- Dropdown Areas -->
<div id="dropdown-router" class="dropdown">
  <?php
  $folder = "img/router";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->'; // Debug output
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-firewall" class="dropdown">
  <?php
  $folder = "img/firewall";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-switch" class="dropdown">
  <?php
  $folder = "img/switch";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-access-point" class="dropdown">
  <?php
  $folder = "img/access-point";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-server" class="dropdown">
  <?php
  $folder = "img/server";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-client" class="dropdown">
  <?php
  $folder = "img/client";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-nas" class="dropdown">
  <?php
  $folder = "img/nas";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-modem" class="dropdown">
  <?php
  $folder = "img/modem";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-proxy" class="dropdown">
  <?php
  $folder = "img/proxy";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-repeater" class="dropdown">
  <?php
  $folder = "img/repeater";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-gateway" class="dropdown">
  <?php
  $folder = "img/gateway";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-voip" class="dropdown">
  <?php
  $folder = "img/voip";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-cam" class="dropdown">
  <?php
  $folder = "img/cam";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-printer" class="dropdown">
  <?php
  $folder = "img/printer";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-reader" class="dropdown">
  <?php
  $folder = "img/reader";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

<!-- Dropdown Areas -->
<div id="dropdown-other" class="dropdown">
  <?php
  $folder = "img/other";
  $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

  if (is_dir($folder)) {
      $files = scandir($folder);
      foreach ($files as $file) {
          $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
          if (in_array($extension, $allowed_extensions)) {
              $imgPath = $folder . '/' . $file;
              echo '<!-- ' . $imgPath . ' -->';
              echo '<img src="' . $imgPath . '" alt="Switch Icon" data-type="' . $imgPath . '" class="icon" draggable="true">';
          }
      }
  } else {
      echo "Folder not found.";
  }
  ?>
</div>

  
  

 <br>
 <br>
 <br>
 <br>

  <!-- Shared Container -->
  <div id="top-controls">
    <!-- Page Control -->
    <div id="page-controls">
      <label>Page:
        <select id="page-selector"></select>
      </label>
      <button id="add-page">➕ New Page</button>
      <button id="delete-page">🗑️ Delete Page</button>
    </div>
	<div class="button-container">
	  <button id="connect-devices" class="control-button">🔗 Connect Devices</button>
	</div>
    <!-- Category Control -->
    <div id="category-controls">
      <label>Category:
        <select id="category-selector"></select>
      </label>
      <button id="add-category">➕ New Category</button>
      <button id="delete-category">🗑️ Delete Category</button>
    </div>
  </div>

  <!-- Controls (Connect, Notification Settings, Alerts) -->
  
  <div id="controls">
  <?php
    // Determine alert status from the CSV file
    $csvFile = '/var/www/html/drag/offline.csv';
    $alertCount = 0;
    if (file_exists($csvFile)) {
      if (($handle = fopen($csvFile, 'r')) !== false) {
        // Read header
        $header = fgetcsv($handle);
        // Count every non-empty row
        while (($row = fgetcsv($handle)) !== false) {
          if (array_filter($row)) {
            $alertCount++;
          }
        }
        fclose($handle);
      }
    }
    $alertBtnColor = ($alertCount > 0) ? '#d32f2f' : '#28a745'; // Red for alerts, green otherwise
    $alertBtnText = ($alertCount > 0) ? 'Current Alerts 🚨' : 'Current Alerts ✅';
  ?>
  
  <button id="settings-btn" class="control-button" title="Notification Settings" onclick="window.open('setting.php', '_blank')">
    🚨 Notification Settings
  </button>
  <button id="alerts-btn" class="control-button" title="Current Alerts" style="background-color: <?php echo $alertBtnColor; ?>;"
    onclick="window.open('alerts.php', '_blank')">
    <?php echo $alertBtnText; ?>
  </button>
</div>

<!-- Health Status Container (wird nicht vom Refresh überschrieben) -->
<div id="health-status-container" style="margin: 10px 0; text-align: center;">
  <span id="health-status" style="font-size:16px; font-weight:bold;"></span>
</div>


  <!-- Canvas -->
  <div id="canvas"></div>

  <!-- Context Menu -->
  <div id="context-menu" class="modern-context" style="display:none; position:absolute; background:#fff; border:1px solid #ccc; padding:15px; border-radius:10px; box-shadow:0 8px 16px rgba(0,0,0,0.2); z-index:1000; min-width:260px;">
    <div class="form-row">
      <label>IP/DNS:</label>
      <input type="text" id="context-ip" placeholder="192.168.0.1">
    </div>
    <div class="form-row">
      <label>Description:</label>
      <input type="text" id="context-desc" placeholder="e.g. Kitchen Router">
    </div>
    <div class="form-row">
      <label>Category:</label>
      <select id="context-category"></select>
    </div>
    <div class="form-row link-row">
      <label>Link:</label>
      <div class="link-group">
        <input type="text" id="context-link" placeholder="http://example.com">
        <button id="visit-button">🔗</button>
      </div>
    </div>
    <p id="display-category">Category: default</p>
    <div class="button-row">
      <button id="save-button" class="save">💾 Save</button>
      <button id="delete-device-button" class="delete">🗑️ Delete</button>
      <button id="cancel-button" class="cancel">❌ Cancel</button>
    </div>
  </div>

  <script>
  window.addEventListener("DOMContentLoaded", () => {
      // Global variables
      const canvas = document.getElementById("canvas");
      let selectedDevices = [];
      let connections = [];
      let currentPage = "default";
      let availablePages = [];
      let contextDevice = null;
      let currentCategory = "default";
      let availableCategories = [];
      let iconWasDragged = false;
      let iconDragStartX = 0;
      let iconDragStartY = 0;
      const DRAG_THRESHOLD = 20;

      // ---------------------------
      // Page management functions
      // ---------------------------
      function getCurrentPage() {
        return currentPage;
      }
      
      function updatePageSelector() {
        const select = document.getElementById("page-selector");
        select.innerHTML = "";
        availablePages.forEach(p => {
          const option = document.createElement("option");
          option.value = p;
          option.textContent = p;
          if (p === currentPage) option.selected = true;
          select.appendChild(option);
        });
      }
      
      function isReallyOnline(timeout = 3000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve(false), timeout);

    fetch("https://1.1.1.1/cdn-cgi/trace", { method: "GET", cache: "no-cache" })
      .then(response => {
        clearTimeout(timer);
        resolve(response.ok);
      })
      .catch(() => {
        clearTimeout(timer);
        resolve(false);
      });
  });
}

	function addNewPage() {
	  const name = prompt("Name new page:");
	  if (!name) return;

	  isReallyOnline().then(online => {
		if (!online) {
		  alert("No internet connection. Cannot save the new page.");
		  return;
		}

		if (!availablePages.includes(name)) {
		  fetch("save_page.php", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ page: name })
		  })
		  .then(res => res.text())
		  .then(responseText => {
			availablePages.push(name);
			currentPage = name;
			updatePageSelector();
			loadDevicesForPage(currentPage);
		  })
		  .catch(err => console.error("Error in addNewPage():", err));
		} else {
		  console.log("Page already exists.");
		}
	  });
	}
      
      function changePage(newPage) {
        currentPage = newPage;
        loadDevicesForPage(currentPage);
      }
      
      // ---------------------------
      // Category management functions
      // ---------------------------
      function updateCategorySelector() {
        const select = document.getElementById("category-selector");
        select.innerHTML = "";
        availableCategories.forEach(cat => {
          const option = document.createElement("option");
          option.value = cat;
          option.textContent = cat;
          if (cat === currentCategory) option.selected = true;
          select.appendChild(option);
        });
      }
      
      function isReallyOnline(timeout = 3000) {
		  return new Promise((resolve) => {
			const timer = setTimeout(() => resolve(false), timeout);

			fetch("https://1.1.1.1/cdn-cgi/trace", { method: "GET", cache: "no-cache" })
			  .then(response => {
				clearTimeout(timer);
				resolve(response.ok);
			  })
			  .catch(() => {
				clearTimeout(timer);
				resolve(false);
			  });
		  });
		}

		function addNewCategory() {
		  const name = prompt("Enter a name for the new category:");
		  if (!name) return;

		  isReallyOnline().then(online => {
			if (!online) {
			  alert("No internet connection. Cannot save the new category.");
			  return;
			}

			if (!availableCategories.includes(name)) {
			  fetch("save_category.php", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ category: name })
			  })
			  .then(res => res.text())
			  .then(responseText => {
				availableCategories.push(name);
				currentCategory = name;
				updateCategorySelector();
			  })
			  .catch(err => console.error("Error in addNewCategory():", err));
			} else {
			  console.log("Category already exists.");
			}
		  });
		}

      
      function changeCategory(newCat) {
        currentCategory = newCat;
      }
      
      function deleteCategory() {
        if (currentCategory === "default") {
          alert("The default category 'default' cannot be deleted.");
          return;
        }
        if (!confirm(`Really delete category '${currentCategory}'?`)) return;
        fetch("delete_category.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ category: currentCategory })
        })
        .then(res => res.text())
        .then(() => {
          availableCategories = availableCategories.filter(cat => cat !== currentCategory);
          currentCategory = availableCategories.length ? availableCategories[0] : "default";
          updateCategorySelector();
        });
      }
      
      // ---------------------------
      // Device, Drag & Drop, and Connection functions
      // ---------------------------
      function makeDraggable(el) {
        el.addEventListener("mousedown", function(e) {
          if (e.button !== 0) return;
          e.preventDefault();
          // Calculate the position of the canvas in the viewport
          const canvasRect = canvas.getBoundingClientRect();
          // Calculate the position of the element in the viewport
          const elRect = el.getBoundingClientRect();
          // Determine the offset from the click point to the left and top of the element
          const offsetX = e.clientX - elRect.left;
          const offsetY = e.clientY - elRect.top;

          let isDragging = true;
          function onMouseMove(e) {
            if (isDragging) {
              // Position the element relative to the canvas so that the click point stays the same
              el.style.left = `${e.clientX - canvasRect.left - offsetX}px`;
              el.style.top = `${e.clientY - canvasRect.top - offsetY}px`;
              updateLines(el);
            }
          }
          function onMouseUp() {
            isDragging = false;
            document.removeEventListener("mousemove", onMouseMove);
            document.removeEventListener("mouseup", onMouseUp);
            window.removeEventListener("mouseup", onMouseUp);
            saveDeviceToServer({
              id: el.id,
              type: el.dataset.type,
              label: el.dataset.label || "",
              ip: el.dataset.ip || "",
              description: el.dataset.label || "",
              x: parseInt(el.style.left),
              y: parseInt(el.style.top),
              page: getCurrentPage()
            });
          }
          document.addEventListener("mousemove", onMouseMove);
          document.addEventListener("mouseup", onMouseUp);
          window.addEventListener("mouseup", onMouseUp);
        });
        el.ondragstart = () => false;
      }
      
      function updateLines(movedDevice) {
        connections.forEach(conn => {
          if (conn.from === movedDevice || conn.to === movedDevice) {
            conn.line.position();
          }
        });
      }
      
      function saveDeviceToServer(data) {
        fetch("save_device.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        })
        .then(res => res.text())
        .then(res => console.log("Saved:", res));
      }
      
      function loadDevicesForPage(page) {
  connections.forEach(conn => {
    if (conn.line && typeof conn.line.remove === "function") {
      conn.line.remove();
    }
  });
  connections = [];
  selectedDevices = [];
  canvas.innerHTML = "";
  fetch("load_devices.php")
    .then(res => res.json())
    .then(devices => {
      console.log("DEBUG: Loaded Devices:", devices);
      devices.filter(d => d.page === page).forEach(data => {
        const device = document.createElement("div");
        device.className = "device";
        device.style.left = `${data.x}px`;
        device.style.top = `${data.y}px`;
        // Set the data-type, which now contains the image path
        device.dataset.type = data.type;
        device.dataset.label = data.description || "";
        device.dataset.ip = data.ip || "";
        device.dataset.category = data.category || "default";
        device.dataset.link = data.reserve_2 || "";
        device.id = data.id;
        device.title = `IP: ${data.ip || "unknown"}\n${data.description || ""}\nCategory: ${data.category || "default"}\nLink: ${data.reserve_2 || ""}`;
        if (data.description && data.description.trim() !== "") {
          const label = document.createElement("div");
          label.className = "device-label";
          label.textContent = data.description;
          device.appendChild(label);
        }
        const img = document.createElement("img");
        // Use the image path stored in data-type
        img.src = data.type;
        img.alt = data.type;
        device.appendChild(img);
        canvas.appendChild(device);
        makeDraggable(device);
        device.addEventListener("click", function () {
          device.classList.toggle("selected");
          if (device.classList.contains("selected")) {
            selectedDevices.push(device);
          } else {
            selectedDevices = selectedDevices.filter(d => d !== device);
          }
        });
      });
    })
    .then(() => {
      fetch("load_connections.php")
        .then(res => res.json())
        .then(lines => {
          lines.filter(conn => conn.page === page).forEach(conn => {
            const fromEl = document.getElementById(conn.from);
            const toEl = document.getElementById(conn.to);
            if (fromEl && toEl) {
              const line = new LeaderLine(fromEl, toEl, {
                color: 'gray',
                size: 2,
                path: 'straight',
                startPlug: 'arrow1',
                endPlug: 'arrow1',
                startPlugSize: 1.5,
                endPlugSize: 1.5,
                zIndex: 0
              });
              connections.push({ from: fromEl, to: toEl, line });
            }
          });
        });
    });
}


      // ---------------------------
      // Context menu and related functions
      // ---------------------------
      function closeContextMenu() {
        document.getElementById("context-menu").style.display = "none";
        contextDevice = null;
      }
      
      function saveContextData() {
        if (!contextDevice) return;
        const ip = document.getElementById("context-ip").value;
        const desc = document.getElementById("context-desc").value;
        const category = document.getElementById("context-category").value || "default";
        const link = document.getElementById("context-link").value || "";
        contextDevice.dataset.ip = ip;
        contextDevice.dataset.label = desc;
        contextDevice.dataset.category = category;
        contextDevice.dataset.link = link;
        contextDevice.title = `IP: ${ip}\n${desc}\nCategory: ${category}\nLink: ${link}`;
        const oldLabel = contextDevice.querySelector(".device-label");
        if (oldLabel) oldLabel.remove();
        if (desc.trim() !== "") {
          const labelDiv = document.createElement("div");
          labelDiv.className = "device-label";
          labelDiv.textContent = desc;
          contextDevice.appendChild(labelDiv);
        }
        saveDeviceToServer({
          id: contextDevice.id,
          type: contextDevice.dataset.type,
          label: desc,
          ip: ip,
          description: desc,
          category: category,
          link: link,
          x: parseInt(contextDevice.style.left),
          y: parseInt(contextDevice.style.top),
          page: getCurrentPage()
        });
        closeContextMenu();
      }
      
      document.getElementById("visit-button").addEventListener("click", () => {
        const url = document.getElementById("context-link").value;
        if (url && url.trim() !== "") {
          const fullUrl = (/^(https?:\/\/)/i.test(url)) ? url : "http://" + url;
          window.open(fullUrl, "_blank");
        } else {
          alert("No link provided.");
        }
      });
      
      document.getElementById("save-button").addEventListener("click", saveContextData);
      document.getElementById("delete-device-button").addEventListener("click", deleteDevice);
      document.getElementById("cancel-button").addEventListener("click", closeContextMenu);
      
      window.addEventListener("click", function (e) {
        const menu = document.getElementById("context-menu");
        if (!menu.contains(e.target)) {
          menu.style.display = "none";
        }
      });
      
      document.getElementById("delete-page").addEventListener("click", () => {
        if (currentPage === "default") {
          alert("The default page 'default' cannot be deleted.");
          return;
        }
        if (!confirm(`Really delete page '${currentPage}'?`)) return;
        fetch("delete_page.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ page: currentPage })
        })
        .then(res => res.text())
        .then(() => {
          availablePages = availablePages.filter(p => p !== currentPage);
          currentPage = "default";
          updatePageSelector();
          loadDevicesForPage(currentPage);
        });
      });
      
      function deleteDevice() {
        if (!contextDevice) return;
        if (!confirm("Really delete device?")) return;
        connections = connections.filter(conn => {
          if (conn.from === contextDevice || conn.to === contextDevice) {
            conn.line.remove();
            return false;
          }
          return true;
        });
        contextDevice.remove();
        fetch("delete_device.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: contextDevice.id })
        })
        .then(res => res.text())
        .then(res => console.log("Device deleted:", res));
        closeContextMenu();
      }
      
      // ---------------------------
      // Event listeners: Drag & Drop, Toolbar
      // ---------------------------
      document.querySelectorAll(".icon").forEach(icon => {
        icon.addEventListener("dragstart", e => {
          iconDragStartX = e.clientX;
          iconDragStartY = e.clientY;
          iconWasDragged = false;
          e.dataTransfer.setData("type", icon.dataset.type);
          e.dataTransfer.setData("src", icon.src);
          e.dataTransfer.setData("fromToolbar", "true");
        });
        icon.addEventListener("drag", e => {
          const dx = e.clientX - iconDragStartX;
          const dy = e.clientY - iconDragStartY;
          if (Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD) {
            iconWasDragged = true;
          }
        });
        icon.addEventListener("dragend", e => {
          // No extra action
        });
      });
      
      canvas.addEventListener("dragover", e => {
        e.preventDefault();
      });
      
      canvas.addEventListener("drop", e => {
        e.preventDefault();
        if (e.dataTransfer.getData("fromToolbar") !== "true") return;
        if (!iconWasDragged) return;
        const type = e.dataTransfer.getData("type");
        const src = e.dataTransfer.getData("src");
        if (!type || !src) return;
        e.dataTransfer.clearData();
        iconWasDragged = false;
        // Get the position relative to the canvas
        const rect = canvas.getBoundingClientRect();
        const offsetX = e.clientX - rect.left;
        const offsetY = e.clientY - rect.top;
        const device = document.createElement("div");
        device.className = "device";
        device.style.left = `${offsetX}px`;
        device.style.top = `${offsetY}px`;
        device.dataset.type = type;
        device.id = "device-" + Date.now();
        const img = document.createElement("img");
        img.src = src;
        img.alt = type;
        device.appendChild(img);
        canvas.appendChild(device);
        makeDraggable(device);
        device.addEventListener("click", function () {
          device.classList.toggle("selected");
          if (device.classList.contains("selected")) {
            selectedDevices.push(device);
          } else {
            selectedDevices = selectedDevices.filter(d => d !== device);
          }
        });
        saveDeviceToServer({
          id: device.id,
          type: type,
          label: "",
          ip: "",
          description: "",
          x: parseInt(device.style.left),
          y: parseInt(device.style.top),
          page: getCurrentPage()
        });
      });
      
      canvas.addEventListener("contextmenu", function (e) {
        const device = e.target.closest(".device");
        if (!device) return;
        e.preventDefault();
        contextDevice = device;
        document.getElementById("context-ip").value = device.dataset.ip || "";
        document.getElementById("context-desc").value = device.dataset.label || "";
        const catSelect = document.getElementById("context-category");
        catSelect.innerHTML = "";
        availableCategories.forEach(cat => {
          const option = document.createElement("option");
          option.value = cat;
          option.textContent = cat;
          if (device.dataset.category === cat) {
            option.selected = true;
          }
          catSelect.appendChild(option);
        });
        document.getElementById("context-link").value = device.dataset.link || "";
        document.getElementById("display-category").textContent = "Category: " + (device.dataset.category || "default");
        const menu = document.getElementById("context-menu");
        menu.style.left = e.pageX + "px";
        menu.style.top = e.pageY + "px";
        menu.style.display = "block";
      });

      // ---------------------------
      // Event listeners: Connect devices
      // ---------------------------
      document.getElementById("connect-devices").addEventListener("click", () => {
		  if (selectedDevices.length === 2) {
			const fromId = selectedDevices[0].id;
			const toId = selectedDevices[1].id;
			const line = new LeaderLine(selectedDevices[0], selectedDevices[1], {
			  color: 'gray',
			  size: 2,
			  path: 'straight',
			  startPlug: 'arrow1',
			  endPlug: 'arrow1',
			  startPlugSize: 1.5,
			  endPlugSize: 1.5,
			  zIndex: 0
			});
			connections.push({ from: selectedDevices[0], to: selectedDevices[1], line });
			fetch("save_connection.php", {
			  method: "POST",
			  headers: { "Content-Type": "application/json" },
			  body: JSON.stringify({ from: fromId, to: toId, page: getCurrentPage() })
			})
			.then(res => res.text())
			.then(res => console.log("Connection saved:", res))
			.catch(err => console.error("Error saving connection:", err));
			selectedDevices.forEach(d => d.classList.remove("selected"));
			selectedDevices = [];
		  } else {
			alert("Please select exactly 2 devices.");
			// Alle markierten Geräte abwählen:
			selectedDevices.forEach(d => d.classList.remove("selected"));
			selectedDevices = [];
		  }
		});


      // ---------------------------
      // Regularly update device status
      // ---------------------------
      setInterval(() => {
        fetch("load_devices.php")
          .then(res => res.json())
          .then(devices => {
            devices.filter(d => d.page === currentPage).forEach(data => {
              const el = document.getElementById(data.id);
              if (el) {
                const isOnline = data.online === "1";
                el.style.borderColor = isOnline ? "green" : "red";
              }
            });
          });
      }, 10000);
      
      // ---------------------------
      // Initialization: Load categories and pages, update dropdowns, and load devices
      // ---------------------------
      fetch("load_categories.php")
        .then(res => res.json())
        .then(categories => {
          availableCategories = categories && categories.length ? categories : ["default"];
          if (!availableCategories.includes("default")) availableCategories.unshift("default");
          currentCategory = availableCategories[0];
          updateCategorySelector();
          const ctxCat = document.getElementById("context-category");
          ctxCat.innerHTML = "";
          availableCategories.forEach(cat => {
            const option = document.createElement("option");
            option.value = cat;
            option.textContent = cat;
            ctxCat.appendChild(option);
          });
        })
        .catch(err => {
          console.error("Error loading categories:", err);
          availableCategories = ["default"];
          currentCategory = "default";
          updateCategorySelector();
        });
      
      const urlParams = new URLSearchParams(window.location.search);
      const pageParam = urlParams.get("page");
      if (pageParam) {
        currentPage = pageParam;
      }
      
      fetch("load_pages.php")
        .then(res => res.json())
        .then(pages => {
          availablePages = pages && pages.length ? pages : ["default"];
          if (!availablePages.includes("default")) availablePages.unshift("default");
          updatePageSelector();
          loadDevicesForPage(currentPage);
        })
        .catch(err => {
          console.error("Error loading pages:", err);
          availablePages = ["default"];
          updatePageSelector();
          loadDevicesForPage(currentPage);
        });
      
      document.getElementById("page-selector").addEventListener("change", e => {
        changePage(e.target.value);
      });
      
      document.getElementById("category-selector").addEventListener("change", e => {
        changeCategory(e.target.value);
      });
      
      document.getElementById("add-category").addEventListener("click", addNewCategory);
      document.getElementById("delete-category").addEventListener("click", deleteCategory);
      document.getElementById("add-page").addEventListener("click", addNewPage);
    });

    // Tab functionality
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        // Reset all tabs
        tabButtons.forEach(btn => btn.classList.remove('active'));
        // Mark the active tab
        button.classList.add('active');
        
        // Hide all dropdowns
        document.querySelectorAll('.dropdown').forEach(drop => drop.classList.remove('active'));
        
        // Show the dropdown for the clicked tab
        const tab = button.getAttribute('data-tab');
        const dropdown = document.getElementById('dropdown-' + tab);
        if (dropdown) {
          dropdown.classList.add('active');
        }
      });
    });

 $(document).ready(function() {
    // Function that updates the content of the div
    function updateControls() {
      // Reload the current content of the #controls div from the current URL
      $("#controls").load(window.location.href + " #controls>*");
    }
    
    // Initial update when the page loads
    updateControls();
    
    // Update every 10 seconds
    setInterval(updateControls, 10000);
  });

function updateHealthStatus(){
  $.get('health.txt', function(data){
    var healthTimestamp = parseInt(data.trim());
    var currentTime = Math.floor(Date.now() / 1000);
    var diff = currentTime - healthTimestamp;
    var statusMessage = "";
    var color = "";
    // Wenn der gespeicherte Timestamp älter als 1 Stunde (3600 Sekunden) ist:
    if(diff > 3600) {
      statusMessage = "ERROR occurred, restart the system or clear browser cache or use other browser";
      color = "red";
    } else {
      statusMessage = "System health OK";
      color = "green";
    }
    $('#health-status').text(statusMessage).css("color", color);
  })
  .fail(function() {
    $('#health-status').text("Cannot read system health").css("color", "red");
  });
}
  
// Update alle 10 Sekunden
setInterval(updateHealthStatus, 10000);
updateHealthStatus();

document.addEventListener('DOMContentLoaded', () => {
  const inputs = document.querySelectorAll('input[type="text"]');
  inputs.forEach(input => {
    input.addEventListener('input', function() {
      this.value = this.value.replace(/\s/g, '_');
    });
  });
});

  </script>
</body>
</html>
