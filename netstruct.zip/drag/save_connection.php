<?php
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["from"], $data["to"], $data["page"])) {
  http_response_code(400);
  echo json_encode(["error" => "Ung�ltige Daten"]);
  exit;
}

$file = "connections.json";
$connections = [];

if (file_exists($file)) {
  $json = file_get_contents($file);
  $connections = json_decode($json, true) ?? [];
}

// Pr�fen ob Verbindung schon existiert
foreach ($connections as $conn) {
  if (
    $conn["from"] === $data["from"] &&
    $conn["to"] === $data["to"] &&
    $conn["page"] === $data["page"]
  ) {
    echo json_encode(["message" => "Verbindung bereits vorhanden"]);
    exit;
  }
}

$connections[] = $data;
file_put_contents($file, json_encode($connections, JSON_PRETTY_PRINT));

echo json_encode(["message" => "Verbindung gespeichert"]);
?>
