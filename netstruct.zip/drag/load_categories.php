<?php
$filename = 'categories.json';
if (!file_exists($filename)) {
    $defaultCategories = ["default"];
    file_put_contents($filename, json_encode($defaultCategories));
}
header('Content-Type: application/json');
echo file_get_contents($filename);
?>
