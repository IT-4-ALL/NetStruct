<?php
$data = json_decode(file_get_contents("php://input"), true);
$deviceId = $data["id"];

$devicesFile = "devices.csv";
$alarmFile = "offline.csv";

// 1. Load devices.csv
$devices = array_map("str_getcsv", file($devicesFile));
$header = array_shift($devices); // first row = headers

$deviceIP = null;
$newDevices = [];

// 2. Find and remove the device with matching ID
foreach ($devices as $row) {
    if (trim($row[0]) === trim($deviceId)) {
        $deviceIP = trim($row[3]); // Column 3 = IP
        continue; // skip this row (delete it)
    }
    $newDevices[] = $row;
}

// 3. Rewrite devices.csv
$fp = fopen($devicesFile, "w");
fputcsv($fp, $header);
foreach ($newDevices as $row) {
    fputcsv($fp, $row);
}
fclose($fp);

// 4. If IP found, clean up alarm.csv
$deletedAlarms = 0;

if ($deviceIP) {
    $alarms = array_map("str_getcsv", file($alarmFile));
    $alarmHeader = array_shift($alarms);

    // Filter out alarms matching the device IP
    $filteredAlarms = array_filter($alarms, function($row) use ($deviceIP, &$deletedAlarms) {
        if (trim($row[0]) === trim($deviceIP)) {
            $deletedAlarms++;
            return false;
        }
        return true;
    });

    // Rewrite alarm.csv
    $fp2 = fopen($alarmFile, "w");
    fputcsv($fp2, $alarmHeader);
    foreach ($filteredAlarms as $row) {
        fputcsv($fp2, $row);
    }
    fclose($fp2);
}

// 5. Return confirmation
echo "Device deleted. Alarms removed for IP {$deviceIP}: {$deletedAlarms}";
?>
