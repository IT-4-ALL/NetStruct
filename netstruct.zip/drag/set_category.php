<?php
// set_category.php

// JSON-Eingabe auslesen
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["id"]) || !isset($data["category"])) {
    echo json_encode(["error" => "ID oder Kategorie nicht angegeben"]);
    exit;
}

$deviceId = $data["id"];
$newCategory = $data["category"];
$csvFile = "devices.csv";

// Prüfen, ob die CSV-Datei existiert
if (!file_exists($csvFile)) {
    echo json_encode(["error" => "CSV-Datei nicht gefunden"]);
    exit;
}

// CSV-Datei einlesen
$rows = file($csvFile);
if (count($rows) === 0) {
    echo json_encode(["error" => "CSV-Datei ist leer"]);
    exit;
}

// Die erste Zeile enthält die Header
$header = str_getcsv(array_shift($rows));

// Finde den Index der Spalte "reserve_1"
$reserve1Index = array_search("reserve_1", $header);
if ($reserve1Index === false) {
    echo json_encode(["error" => "Spalte reserve_1 nicht gefunden"]);
    exit;
}

$found = false;
$updatedRows = [];

foreach ($rows as $row) {
    $fields = str_getcsv($row);
    if ($fields[0] === $deviceId) {
        // Aktualisiere die reserve_1-Spalte mit der neuen Kategorie
        $fields[$reserve1Index] = $newCategory;
        $found = true;
    }
    $updatedRows[] = $fields;
}

if (!$found) {
    echo json_encode(["error" => "Gerät mit der ID $deviceId nicht gefunden"]);
    exit;
}

// CSV-Datei mit aktualisierten Daten neu schreiben
$file = fopen($csvFile, "w");
fputcsv($file, $header);
foreach ($updatedRows as $fields) {
    fputcsv($file, $fields);
}
fclose($file);

echo "OK";
?>
