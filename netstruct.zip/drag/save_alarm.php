<?php
header("Content-Type: application/json");

// Eingabedaten empfangen
$data = json_decode(file_get_contents("php://input"), true);

// Eingabe validieren
if (!isset($data["category"]) || !isset($data["api_function"]) || !isset($data["active"])) {
    echo json_encode(["status" => "error", "message" => "Missing fields."]);
    exit;
}

$category = trim($data["category"]);
$api = trim($data["api_function"]);
$alarm_auto = $data["active"] ? "1" : "0";

// CSV-Datei und Kopfzeile
$csv_file = "alarms.csv";
$headers = ["category", "api", "trigger_auto", "trigger_manuel", "alarm_auto", "alarm_manuel", "mute_auto", "mute_manuel", "reserve_1", "reserve_2", "reserve_3", "reserve_4", "reserve_5"];
$rows = [];
$updated = false;

// Falls Datei existiert, Daten laden
if (file_exists($csv_file)) {
    if (($handle = fopen($csv_file, "r")) !== false) {
        $file_headers = fgetcsv($handle); // Erste Zeile = Kopfzeile
        while (($row = fgetcsv($handle)) !== false) {
            $entry = array_combine($file_headers, $row);
            if ($entry["category"] === $category) {
                // Bestehenden Eintrag aktualisieren
                $entry["api"] = $api;
                $entry["alarm_auto"] = $alarm_auto;
                $updated = true;
            }
            $rows[] = $entry;
        }
        fclose($handle);
    }
}

// Wenn Kategorie nicht gefunden wurde ? neuen Eintrag anlegen
if (!$updated) {
    $new = array_fill_keys($headers, "");
    $new["category"] = $category;
    $new["api"] = $api;
    $new["alarm_auto"] = $alarm_auto;
    $rows[] = $new;
}

// CSV-Datei (�berschreiben)
if (($handle = fopen($csv_file, "w")) !== false) {
    fputcsv($handle, $headers);
    foreach ($rows as $row) {
        $line = [];
        foreach ($headers as $col) {
            $line[] = isset($row[$col]) ? $row[$col] : "";
        }
        fputcsv($handle, $line);
    }
    fclose($handle);
    echo json_encode(["status" => "success", "updated" => $updated]);
} else {
    echo json_encode(["status" => "error", "message" => "Could not write CSV."]);
}
