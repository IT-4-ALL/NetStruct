<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Alarm Management</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f8f9fb;
      padding: 30px;
    }

    h2 {
      margin-bottom: 8px;
      color: #333;
    }

    .description {
      margin-bottom: 25px;
      font-size: 15px;
      color: #555;
      background: #eef4ff;
      padding: 12px 15px;
      border-left: 4px solid #007bff;
      border-radius: 4px;
    }

    .category-entry {
      background: #fff;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 10px;
      margin-bottom: 8px;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .category-entry:hover {
      background: #e9f2ff;
    }

    #alarm-context {
      position: absolute;
      background: #fff;
      border: 1px solid #ccc;
      padding: 15px;
      border-radius: 8px;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
      z-index: 1000;
      width: 280px;
      display: none;
    }

    #alarm-context label {
      display: block;
      margin-bottom: 10px;
      font-weight: 500;
    }

    #alarm-context input[type="checkbox"] {
      margin-right: 8px;
    }

    #alarm-context input[type="text"] {
      width: 100%;
      padding: 6px;
      margin-top: 5px;
      margin-bottom: 12px;
      border-radius: 4px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    #alarm-context button {
      padding: 8px 12px;
      margin-right: 6px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      transition: transform 0.3s ease, filter 0.3s ease;
    }

    #alarm-context button:first-child {
      background-color: #28a745;
      color: #fff;
    }

    #alarm-context button:last-child {
      background-color: #dc3545;
      color: #fff;
    }

    #alarm-context button:hover {
      transform: scale(1.05);
      filter: brightness(1.1);
    }

    /* Info Box Style */
    #alarm-context .info-box {
      margin-top: 15px;
      font-size: 13px;
      line-height: 1.5;
      color: #444;
      background: #f9f9f9;
      padding: 10px;
      border-left: 4px solid #17a2b8;
      border-radius: 6px;
    }
  </style>
</head>
<body>
<iframe src="https://itfourall.com/banner_network.php" width="100%" height="100" style="border: none;"></iframe>
<h2>Categories with Alarm Management</h2>
<div class="description">
  In this interface, you can manage alarm settings for each category. Click on a category to configure whether devices should trigger alerts and optionally define an API action.
</div>

<div id="category-list"></div>

<!-- Alarm form -->
<div id="alarm-context">
  <label>
    <input type="checkbox" id="alarm-active"> Alarm active
  </label>

  <label>
    API Function:
    <input type="text" id="api-function" placeholder="e.g. sendWebhook">
  </label>

  <button onclick="saveAlarm()">Save</button>
  <button onclick="closeAlarmMenu()">Cancel</button>

  <!-- Info box -->
  <div class="info-box">
    <strong>Info:</strong><br>
    This section allows you to configure whether a notification should be triggered for the selected category when it becomes active.<br><br>
    • If <strong>enabled</strong>, all devices assigned to this category will be monitored for alarms.<br>
    • If an <strong>API link</strong> is set, it will be executed <em>once</em> when a device failure is detected.<br>
    • The link can be used to trigger external actions, such as sending an email or activating another alert system.
  </div>
</div>

<script>
let currentCategory = null;
let alarmConfigs = {};
let justOpened = false;

function loadCategories() {
  const cacheBuster = "?cb=" + new Date().getTime();

  fetch("categories.json" + cacheBuster)
    .then(res => res.json())
    .then(categories => {
      fetch("alarms.csv" + cacheBuster)
        .then(response => response.text())
        .then(csvText => {
          const rows = csvText.trim().split("\n").map(line => line.split(","));
          const headers = rows.shift();
          rows.forEach(row => {
            const entry = {};
            headers.forEach((h, i) => entry[h] = row[i]);
            if (entry.category) alarmConfigs[entry.category] = entry;
          });

          const container = document.getElementById("category-list");
          container.innerHTML = "";
          categories.forEach(cat => {
            const div = document.createElement("div");
            div.textContent = cat;
            div.className = "category-entry";
            div.addEventListener("mousedown", (e) => {
              if (e.button === 0) {
                openAlarmMenu(e.pageX, e.pageY, cat);
              }
            });
            container.appendChild(div);
          });
        })
        .catch(() => {
          console.warn("No alarms.csv found – using default values.");
        });
    })
    .catch(err => {
      console.error("Error loading categories:", err);
    });
}

function openAlarmMenu(x, y, category) {
  currentCategory = category;
  const alarmData = alarmConfigs[category] || {};

  document.getElementById("alarm-active").checked = alarmData.alarm_auto === "1";
  document.getElementById("api-function").value = alarmData.api || "";

  const menu = document.getElementById("alarm-context");
  menu.style.left = `${x}px`;
  menu.style.top = `${y}px`;
  menu.style.display = "block";

  justOpened = true;
  setTimeout(() => { justOpened = false; }, 100);
}

function closeAlarmMenu() {
  document.getElementById("alarm-context").style.display = "none";
}

function saveAlarm() {
  const active = document.getElementById("alarm-active").checked;
  const api = document.getElementById("api-function").value.trim();

  fetch("save_alarm.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      category: currentCategory,
      active: active,
      api_function: api
    })
  })
  .then(res => res.text())
  .then(response => {
    console.log("Alarm saved:", response);
    closeAlarmMenu();
    loadCategories();
  })
  .catch(err => {
    console.error("Error saving alarm:", err);
  });
}

window.addEventListener("click", (e) => {
  if (justOpened) return;
  const menu = document.getElementById("alarm-context");
  if (!menu.contains(e.target)) {
    menu.style.display = "none";
  }
});

loadCategories();
</script>

</body>
</html>
