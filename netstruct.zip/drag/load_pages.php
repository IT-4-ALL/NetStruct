<?php
header("Content-Type: application/json");
$pages = file_exists("pages.json") ? json_decode(file_get_contents("pages.json"), true) : ["default"];
echo json_encode($pages);
?>
