<?php
// Name der Datei
$filename = 'testapi.txt';

// Aktuelles Datum und Uhrzeit im gew�nschten Format
$currentTime = date('Y-m-d H:i:s');

// Die aktuelle Zeit in die Datei anh�ngen; wenn die Datei nicht existiert, wird sie erstellt
file_put_contents($filename, $currentTime . PHP_EOL, FILE_APPEND);
?>
