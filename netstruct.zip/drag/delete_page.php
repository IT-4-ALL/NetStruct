<?php
$data = json_decode(file_get_contents("php://input"), true);
$pageToDelete = $data["page"] ?? "";

$pagesFile = "pages.json";
$csvFile = "devices.csv";

if (!$pageToDelete || $pageToDelete === "default") {
    echo "Nicht erlaubt";
    exit;
}

if (!file_exists($csvFile)) {
    echo "CSV-Datei nicht gefunden.";
    exit;
}

$rows = [];
$header = [];

// CSV: Zeilen einlesen und filtern
if (($handle = fopen($csvFile, "r")) !== false) {
    $header = fgetcsv($handle); // Header lesen
    while (($data = fgetcsv($handle)) !== false) {
        $row = array_combine($header, $data);
        if ($row['page'] !== $pageToDelete) {
            $rows[] = $row;
        }
    }
    fclose($handle);
}

// CSV: Neue Datei schreiben
if (($handle = fopen($csvFile, "w")) !== false) {
    fputcsv($handle, $header);
    foreach ($rows as $row) {
        fputcsv($handle, $row);
    }
    fclose($handle);
} else {
    echo "Fehler beim Schreiben der CSV-Datei.";
    exit;
}

// JSON: Seite aus pages.json entfernen
if (file_exists($pagesFile)) {
    $jsonData = json_decode(file_get_contents($pagesFile), true);

    // Seite aus dem Array entfernen
    $jsonData = array_filter($jsonData, function($page) use ($pageToDelete) {
        return $page !== $pageToDelete;
    });

    // Neue JSON-Datei schreiben
    if (file_put_contents($pagesFile, json_encode(array_values($jsonData), JSON_PRETTY_PRINT))) {
        echo "Seite und zugeh�rige Ger�te gel�scht.";
    } else {
        echo "Fehler beim Schreiben der JSON-Datei.";
    }
} else {
    echo "JSON-Datei nicht gefunden.";
}
?>
