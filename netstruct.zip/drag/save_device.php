<?php
$data = json_decode(file_get_contents("php://input"), true);
$csvFile = "devices.csv";

// Header-Definition: reserve_1 ist Kategorie, reserve_8 soll den Link enthalten
$header = [
    "id", "type", "label", "ip", "x", "y", "page",
    "online", "timestamp", "description",
    "reserve_1", "reserve_2", "reserve_3", "reserve_4", "reserve_5",
    "reserve_6", "reserve_7", "reserve_8", "reserve_9", "reserve_10"
];

// Falls die Datei nicht existiert, wird sie neu angelegt
if (!file_exists($csvFile)) {
    $file = fopen($csvFile, "w");
    fputcsv($file, $header);
    fclose($file);
}

// Bestehende Zeilen laden
$rows = file($csvFile);
$existingHeaders = str_getcsv(array_shift($rows));
$updatedRows = [];
$found = false;
$timestamp = date("Y-m-d H:i:s");

// Alle vorhandenen Einträge durchsuchen & ggf. aktualisieren
foreach ($rows as $row) {
    $fields = str_getcsv($row);
    if ($fields[0] === $data["id"]) {
        // Falls ein neuer Kategorie-Wert übergeben wurde, verwende ihn, sonst den bestehenden (Index 10)
        $category = isset($data["category"]) && trim($data["category"]) !== "" ? $data["category"] : $fields[10];
        // Falls ein neuer Link übergeben wurde, verwende ihn, sonst den bestehenden (Index 17 für reserve_8)
        $link = isset($data["link"]) && trim($data["link"]) !== "" ? $data["link"] : $fields[17];
        $fields = [
            $data["id"],
            $data["type"],
            $data["label"] ?? "",
            $data["ip"] ?? "",
            $data["x"],
            $data["y"],
            $data["page"] ?? "default",
            $data["online"] ?? "0",
            $timestamp,
            $data["description"] ?? "",
            $category, // reserve_1: Kategorie
            "",        // reserve_2
            "",        // reserve_3
            "",        // reserve_4
            "",        // reserve_5
            "",        // reserve_6
            "",        // reserve_7
            $link,     // reserve_8: Link
            "",        // reserve_9
            ""         // reserve_10
        ];
        $found = true;
    }
    $updatedRows[] = $fields;
}

// Neues Gerät hinzufügen, falls noch nicht vorhanden
if (!$found) {
    $category = isset($data["category"]) && trim($data["category"]) !== "" ? $data["category"] : "default";
    $link = isset($data["link"]) && trim($data["link"]) !== "" ? $data["link"] : "";
    $updatedRows[] = [
        $data["id"],
        $data["type"],
        $data["label"] ?? "",
        $data["ip"] ?? "",
        $data["x"],
        $data["y"],
        $data["page"] ?? "default",
        $data["online"] ?? "0",
        $timestamp,
        $data["description"] ?? "",
        $category, // reserve_1: Kategorie
        "",        // reserve_2
        "",        // reserve_3
        "",        // reserve_4
        "",        // reserve_5
        "",        // reserve_6
        "",        // reserve_7
        $link,     // reserve_8: Link
        "",        // reserve_9
        ""         // reserve_10
    ];
}

// CSV-Datei neu schreiben
$file = fopen($csvFile, "w");
fputcsv($file, $header);
foreach ($updatedRows as $row) {
    fputcsv($file, $row);
}
fclose($file);

echo "OK";
?>
