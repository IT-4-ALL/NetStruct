<?php
// alerts.php

$offlineFile = '/var/www/html/drag/offline.csv';

// --- Reset-Operation: Wenn der GET-Parameter "reset" gesetzt ist, werden alle Zeilen außer dem Header gelöscht ---
if (isset($_GET['reset'])) {
    if (file_exists($offlineFile)) {
        // Öffne die Datei und lese den Header
        if (($handle = fopen($offlineFile, "r")) !== FALSE) {
            $header = fgetcsv($handle);
            fclose($handle);
        }
        // Schreibe die Datei neu: nur der Header wird behalten
        if (($handle = fopen($offlineFile, "w")) !== FALSE) {
            fputcsv($handle, $header);
            fclose($handle);
        }
    }
    // Umleitung, um eine erneute Verarbeitung zu vermeiden
    header("Location: alerts.php");
    exit;
}

// --- Lösch-Operation, wenn der GET-Parameter "delete" gesetzt ist ---
if (isset($_GET['delete'])) {
    $deleteIp = $_GET['delete'];

    if (file_exists($offlineFile)) {
        $rows = [];
        if (($handle = fopen($offlineFile, "r")) !== FALSE) {
            // Lese Header-Zeile
            $header = fgetcsv($handle);
            // Lese alle weiteren Zeilen
            while (($data = fgetcsv($handle)) !== FALSE) {
                $rows[] = $data;
            }
            fclose($handle);
        }

        // Finde den Index der Spalte "ip"
        $ipIndex = array_search('ip', $header);
        if ($ipIndex !== false) {
            // Filtere alle Zeilen, bei denen die IP NICHT der zu löschenden entspricht
            $rows = array_filter($rows, function($row) use ($ipIndex, $deleteIp) {
                return $row[$ipIndex] != $deleteIp;
            });

            // Schreibe die CSV-Datei neu
            if (($handle = fopen($offlineFile, "w")) !== FALSE) {
                fputcsv($handle, $header);
                foreach ($rows as $row) {
                    fputcsv($handle, $row);
                }
                fclose($handle);
            }
        }
    }
    // Umleitung, damit der GET-Parameter nicht erneut verarbeitet wird
    header("Location: alerts.php");
    exit;
}

// --- Einlesen der offline.csv zum Anzeigen ---
$alerts = [];
if (file_exists($offlineFile)) {
    if (($handle = fopen($offlineFile, "r")) !== FALSE) {
        $header = fgetcsv($handle);
        while (($data = fgetcsv($handle)) !== FALSE) {
            // Kombiniere Header mit den Zeilendaten für einfacheren Zugriff
            $alerts[] = array_combine($header, $data);
        }
        fclose($handle);
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Alerts</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        .delete-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 4px 8px;
            cursor: pointer;
            font-size: 16px;
            line-height: 1;
        }
        /* Styling für den Reset-All Alerts Button in alarmrot */
        .reset-btn {
            background-color: #ff4136; /* alarmrot */
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            transition: box-shadow 0.3s ease, transform 0.3s ease;
        }
        .reset-btn:hover {
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
            transform: translateY(-2px);
        }
        .reset-container {
            text-align: center;
            margin: 20px;
        }
    </style>
</head>
<body>
    <h1 style="text-align:center;">🔔Alerts🚨</h1>
    <iframe src="https://itfourall.com/banner_network.php" width="100%" height="100" style="border: none;"></iframe>
    
    <!-- Reset-All Alerts Button -->
    <div class="reset-container">
        <form method="get" action="alerts.php" onsubmit="return confirm('Möchten Sie wirklich alle Alerts zurücksetzen?');">
            <button type="submit" name="reset" value="true" class="reset-btn">Reset All Alerts</button>
        </form>
    </div>
    
    <?php if (empty($alerts)): ?>
        <p style="text-align:center;">Keine Alerts vorhanden.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>IP</th>
                    <th>Page</th>
                    <th>Description</th>
                    <th>Timestamp</th>
                    <th>Aktion</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alerts as $alert): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($alert['ip']); ?></td>
                        <td><?php echo htmlspecialchars($alert['page']); ?></td>
                        <td><?php echo htmlspecialchars($alert['description']); ?></td>
                        <td data-timestamp="<?php echo htmlspecialchars($alert['timestamp']); ?>"></td>
                        <td>
                            <!-- Löschen-Button als kleines rotes X -->
                            <form method="get" action="alerts.php" onsubmit="return confirm('Eintrag wirklich löschen?');">
                                <input type="hidden" name="delete" value="<?php echo htmlspecialchars($alert['ip']); ?>">
                                <button type="submit" class="delete-btn">&times;</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- JavaScript zur Umwandlung des Timestamps -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const cells = document.querySelectorAll("td[data-timestamp]");
            cells.forEach(cell => {
                const unixTimestamp = parseInt(cell.dataset.timestamp, 10);
                if (!isNaN(unixTimestamp)) {
                    const date = new Date(unixTimestamp * 1000);
                    const options = {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        timeZoneName: 'short'
                    };
                    cell.textContent = date.toLocaleString(undefined, options);
                } else {
                    cell.textContent = "Ungültig";
                }
            });
        });
    </script>
</body>
</html>
